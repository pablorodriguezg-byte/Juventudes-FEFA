import React, { useState } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  FileText, 
  Check, 
  AlertCircle, 
  PlusCircle, 
  ArrowUpRight, 
  Eye, 
  Edit3, 
  BookmarkCheck,
  Maximize2
} from 'lucide-react';
import { ChangeProposal } from '../../types/plenario';

export const SintesisBox: React.FC = () => {
  const { 
    synthesisChapters, 
    updateChapterContent, 
    addChangeProposal, 
    elevateProposalToMotion,
    isDireccionNacional
  } = usePlenario();

  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [isReadingMode, setIsReadingMode] = useState(false);
  const [showProposalModal, setShowProposalModal] = useState(false);
  const [proposalType, setProposalType] = useState<'CONSENSO' | 'DISENSO'>('DISENSO');
  const [proposalText, setProposalText] = useState('');
  const [proposalJustification, setProposalJustification] = useState('');

  const currentChapter = synthesisChapters[activeChapterIndex] || synthesisChapters[0];
  const isSecretary = isDireccionNacional;

  const handleCreateProposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!proposalText.trim() || !proposalJustification.trim()) return;
    addChangeProposal(currentChapter.id, proposalText.trim(), proposalJustification.trim(), proposalType);
    setProposalText('');
    setProposalJustification('');
    setShowProposalModal(false);
  };

  return (
    <div className="flex flex-col h-full w-full min-w-0 bg-white border border-slate-200 rounded-2xl shadow-sm p-3.5 overflow-hidden">
      
      {/* Header corresponding to Sketch: SÍNTESIS NACIONAL */}
      <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-1.5 min-w-0">
          <FileText className="w-4 h-4 text-[#4A154B] shrink-0" />
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider truncate">
            SÍNTESIS NACIONAL
          </h3>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Chapter Quick Selector */}
          <select
            value={activeChapterIndex}
            onChange={(e) => setActiveChapterIndex(Number(e.target.value))}
            className="text-[10px] font-bold text-purple-900 bg-purple-50 border border-purple-200 rounded-lg px-2 py-0.5 focus:outline-none cursor-pointer"
          >
            {synthesisChapters.map((ch, idx) => (
              <option key={ch.id} value={idx}>
                Cap. {ch.number}
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowProposalModal(true)}
            className="p-1 rounded-lg bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white hover:brightness-110 cursor-pointer shadow-xs"
            title="Presentar indicación o planteamiento"
          >
            <PlusCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Document Body */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-xs">
        <div>
          <div className="text-[10px] font-extrabold text-purple-900 uppercase tracking-wider">
            Capítulo {currentChapter.number}: {currentChapter.title}
          </div>
          
          {isSecretary ? (
            <textarea
              value={currentChapter.content}
              onChange={(e) => updateChapterContent(currentChapter.id, e.target.value)}
              rows={3}
              className="w-full mt-1 bg-slate-50 border border-slate-200 rounded-lg p-2 text-[11px] text-slate-800 focus:outline-none focus:bg-white resize-none"
              placeholder="Edición de síntesis oficial..."
            />
          ) : (
            <p className="mt-1 text-[11px] text-slate-700 leading-relaxed bg-slate-50 p-2 rounded-lg border border-slate-200">
              {currentChapter.content}
            </p>
          )}
        </div>

        {/* Consensos */}
        <div>
          <div className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1 mb-1">
            <BookmarkCheck className="w-3 h-3 text-purple-700" />
            <span>Consensos ({currentChapter.consensusItems.length})</span>
          </div>
          <div className="space-y-1">
            {currentChapter.consensusItems.slice(0, 2).map((item, i) => (
              <div key={i} className="text-[10px] text-slate-700 bg-purple-50/60 p-1.5 rounded border border-purple-200 flex items-start gap-1.5">
                <Check className="w-3 h-3 text-[#4A154B] mt-0.5 shrink-0 stroke-[3]" />
                <span className="line-clamp-2">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Disensos en debate */}
        {currentChapter.dissensusItems.length > 0 && (
          <div>
            <div className="text-[10px] font-bold text-rose-700 uppercase flex items-center gap-1 mb-1">
              <AlertCircle className="w-3 h-3 text-rose-600" />
              <span>Indicaciones ({currentChapter.dissensusItems.length})</span>
            </div>
            <div className="space-y-1">
              {currentChapter.dissensusItems.map((prop: ChangeProposal) => (
                <div key={prop.id} className="text-[10px] bg-rose-50/70 p-2 rounded border border-rose-200 flex items-start justify-between gap-1">
                  <div>
                    <span className="font-bold text-rose-800">{prop.authorName} ({prop.authorRegion}):</span>
                    <p className="line-clamp-2 text-slate-800 italic mt-0.5 font-medium">{prop.proposedText}</p>
                  </div>
                  {isDireccionNacional && (
                    <button
                      onClick={() => elevateProposalToMotion(currentChapter.id, prop.id)}
                      className="px-1.5 py-0.5 bg-[#4A154B] text-white rounded text-[9px] font-bold shrink-0 hover:bg-[#5E1B5F] flex items-center gap-0.5 cursor-pointer"
                      title="Elevar indicación a votación parlamentaria"
                    >
                      <ArrowUpRight className="w-2.5 h-2.5" />
                      <span>Votar</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modal: Presentar Indicación */}
      {showProposalModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-5 shadow-2xl text-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-sm font-extrabold text-slate-900 mb-1">
              Presentar Nueva Indicación
            </h3>
            <p className="text-[11px] text-slate-500 mb-3">
              Capítulo {currentChapter.number}: {currentChapter.title}
            </p>

            <form onSubmit={handleCreateProposal} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Tipo de Planteamiento</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setProposalType('DISENSO')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold border ${
                      proposalType === 'DISENSO' ? 'bg-rose-50 border-rose-400 text-rose-800' : 'bg-slate-50 text-slate-600'
                    }`}
                  >
                    Disenso / Enmienda
                  </button>
                  <button
                    type="button"
                    onClick={() => setProposalType('CONSENSO')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold border ${
                      proposalType === 'CONSENSO' ? 'bg-purple-50 border-purple-400 text-purple-900' : 'bg-slate-50 text-slate-600'
                    }`}
                  >
                    Consenso Inmediato
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Redacción Propuesta</label>
                <textarea
                  value={proposalText}
                  onChange={(e) => setProposalText(e.target.value)}
                  rows={2}
                  required
                  placeholder="Texto a incorporar o modificar..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Fundamentación</label>
                <textarea
                  value={proposalJustification}
                  onChange={(e) => setProposalJustification(e.target.value)}
                  rows={2}
                  required
                  placeholder="Argumentos políticos y regionales..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowProposalModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-xs font-bold rounded-xl shadow cursor-pointer"
                >
                  Ingresar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
