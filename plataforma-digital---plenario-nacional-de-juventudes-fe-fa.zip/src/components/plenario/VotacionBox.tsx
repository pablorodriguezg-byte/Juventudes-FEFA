import React, { useState } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  Vote, 
  CheckCircle2, 
  XCircle, 
  MinusCircle, 
  Lock, 
  RotateCcw, 
  Plus, 
  TrendingUp, 
  ShieldCheck,
  ChevronRight,
  X
} from 'lucide-react';

interface VotacionBoxProps {
  onToggleHemiciclo?: () => void;
}

export const VotacionBox: React.FC<VotacionBoxProps> = ({ onToggleHemiciclo }) => {
  const { 
    currentUser, 
    activeMotion, 
    activeMotionId,
    setActiveMotionId,
    motionsHistory,
    castVote, 
    closeVotingForMotion, 
    openVotingForMotion,
    createNewMotion,
    setActiveTab,
    isDireccionNacional,
    isSecretariaTecnica,
    isDelegate,
    canVote
  } = usePlenario();

  const [showLaunchModal, setShowLaunchModal] = useState(false);
  const [launchTitle, setLaunchTitle] = useState('');
  const [launchDesc, setLaunchDesc] = useState('');
  const [launchQuorum, setLaunchQuorum] = useState<'SIMPLE_MAJORITY' | 'TWO_THIRDS'>('SIMPLE_MAJORITY');
  const [immediateLaunch, setImmediateLaunch] = useState(true);

  const hasVoted = currentUser && !!activeMotion.votes[currentUser.id];
  const userVote = currentUser ? activeMotion.votes[currentUser.id] : null;

  // Tally counts
  const votesArray = Object.values(activeMotion.votes);
  const countFavor = votesArray.filter(v => v.vote === 'A_FAVOR').length;
  const countContra = votesArray.filter(v => v.vote === 'EN_CONTRA').length;
  const countAbstencion = votesArray.filter(v => v.vote === 'ABSTENCION').length;
  const totalCast = votesArray.length;

  const handleLaunchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!launchTitle.trim()) return;
    createNewMotion(launchTitle.trim(), launchDesc.trim(), launchQuorum, immediateLaunch);
    setLaunchTitle('');
    setLaunchDesc('');
    setShowLaunchModal(false);
  };

  return (
    <div className="flex flex-col h-full w-full min-w-0 bg-white border border-slate-200 rounded-2xl shadow-sm p-3.5 overflow-hidden">
      
      {/* Header corresponding to Sketch [H] [VOTACIÓN] */}
      <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-2">
          {/* Tag "H" from paper sketch */}
          <div
            className="w-6 h-6 rounded-lg bg-[#4A154B] text-white text-[11px] font-black flex items-center justify-center shadow-xs select-none"
            title="Votación sincronizada con el Hemiciclo en vivo (panel inferior)"
          >
            H
          </div>
          
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <span>VOTACIÓN</span>
            <span className="text-[10px] text-purple-900 font-mono font-bold">({activeMotion.code})</span>
          </h3>
        </div>

        <div className="flex items-center gap-1.5">
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
            activeMotion.status === 'VOTING' 
              ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse' 
              : activeMotion.status === 'APPROVED' 
                ? 'bg-emerald-100 text-emerald-800' 
                : 'bg-slate-100 text-slate-700'
          }`}>
            {activeMotion.status === 'VOTING' ? '● Abierta' : activeMotion.status === 'APPROVED' ? '✓ Aprobada' : 'Cerrada'}
          </span>

          {(isDireccionNacional || isSecretariaTecnica) && (
            <button
              onClick={() => setShowLaunchModal(true)}
              className="p-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 cursor-pointer"
              title="Lanzar nueva votación"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Motion Title & Description */}
      <div className="mb-2 shrink-0">
        <div className="text-[11px] font-bold text-slate-900 line-clamp-1 leading-tight">
          {activeMotion.title}
        </div>
        <div className="text-[10px] text-slate-500 font-mono">
          Quórum: {activeMotion.quorumType === 'TWO_THIRDS' ? '2/3 Calificado' : 'Mayoría Simple (50%+1)'}
        </div>
      </div>

      {/* Radio Voting Buttons (matching Sketch: ○ A FAVOR, ● EN CONTRA, ○ ABSTENERSE) */}
      <div className="flex-1 flex flex-col justify-center space-y-1.5 my-1">
        {activeMotion.status === 'VOTING' ? (
          canVote ? (
            <div className="space-y-1.5">
              {/* Option A FAVOR */}
              <button
                onClick={() => castVote('A_FAVOR')}
                className={`w-full py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-between border cursor-pointer ${
                  userVote?.vote === 'A_FAVOR'
                    ? 'bg-[#4A154B] text-white border-purple-950 shadow-xs ring-2 ring-purple-200'
                    : 'bg-slate-50 hover:bg-purple-50/60 text-slate-800 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                    userVote?.vote === 'A_FAVOR' ? 'border-white bg-white' : 'border-slate-400'
                  }`}>
                    {userVote?.vote === 'A_FAVOR' && <span className="w-1.5 h-1.5 rounded-full bg-[#4A154B]" />}
                  </span>
                  <span className="text-[11px] tracking-wide">A FAVOR</span>
                </div>
                {userVote?.vote === 'A_FAVOR' && (
                  <span className="text-[9px] bg-purple-900 text-white px-1.5 py-0.2 rounded font-mono">
                    Emitido ✓
                  </span>
                )}
              </button>

              {/* Option EN CONTRA */}
              <button
                onClick={() => castVote('EN_CONTRA')}
                className={`w-full py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-between border cursor-pointer ${
                  userVote?.vote === 'EN_CONTRA'
                    ? 'bg-rose-600 text-white border-rose-800 shadow-xs ring-2 ring-rose-200'
                    : 'bg-slate-50 hover:bg-rose-50/60 text-slate-800 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                    userVote?.vote === 'EN_CONTRA' ? 'border-white bg-white' : 'border-slate-400'
                  }`}>
                    {userVote?.vote === 'EN_CONTRA' && <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />}
                  </span>
                  <span className="text-[11px] tracking-wide">EN CONTRA</span>
                </div>
                {userVote?.vote === 'EN_CONTRA' && (
                  <span className="text-[9px] bg-rose-800 text-white px-1.5 py-0.2 rounded font-mono">
                    Emitido ✓
                  </span>
                )}
              </button>

              {/* Option ABSTENERSE */}
              <button
                onClick={() => castVote('ABSTENCION')}
                className={`w-full py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-between border cursor-pointer ${
                  userVote?.vote === 'ABSTENCION'
                    ? 'bg-slate-700 text-white border-slate-900 shadow-xs ring-2 ring-slate-200'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                    userVote?.vote === 'ABSTENCION' ? 'border-white bg-white' : 'border-slate-400'
                  }`}>
                    {userVote?.vote === 'ABSTENCION' && <span className="w-1.5 h-1.5 rounded-full bg-slate-700" />}
                  </span>
                  <span className="text-[11px] tracking-wide">ABSTENERSE</span>
                </div>
                {userVote?.vote === 'ABSTENCION' && (
                  <span className="text-[9px] bg-slate-900 text-white px-1.5 py-0.2 rounded font-mono">
                    Emitido ✓
                  </span>
                )}
              </button>
            </div>
          ) : isDireccionNacional ? (
            <div className="p-2 rounded-xl bg-purple-50 border border-purple-200 text-xs text-left">
              <div className="flex items-center gap-1.5 font-bold text-purple-900 text-[10px]">
                <ShieldCheck className="w-3.5 h-3.5 text-purple-800 shrink-0" />
                <span>Dirección Nacional (DNE): Sin derecho a voto</span>
              </div>
              <p className="text-[9.5px] text-slate-600 mt-0.5 leading-tight">
                El estatuto asigna a la DNE la moderación institucional del Plenario, reservando el voto exclusivamente a delegaciones regionales.
              </p>
            </div>
          ) : isSecretariaTecnica ? (
            <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-xs text-left">
              <div className="flex items-center gap-1.5 font-bold text-amber-900 text-[10px]">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-800 shrink-0" />
                <span>Secretaría Técnica: Mesa y Fe Pública</span>
              </div>
              <p className="text-[9.5px] text-slate-600 mt-0.5 leading-tight">
                Certifica quórums y redacta actas sin emitir voto vinculante.
              </p>
            </div>
          ) : (
            <div className="p-2 text-center text-[10px] text-slate-500 bg-slate-50 rounded-lg">
              Acreditación de delegada/o requerida para votar
            </div>
          )
        ) : (
          <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-center text-[11px] text-slate-700 font-semibold">
            {activeMotion.status === 'APPROVED' ? '✓ Moción aprobada formalmente' : 'Votación cerrada'}
          </div>
        )}
      </div>

      {/* Real-time Tally Progress Strip */}
      <div className="pt-2 border-t border-slate-100 shrink-0">
        <div className="flex items-center justify-between text-[10px] font-mono text-slate-600 mb-1">
          <span>Votos: <strong>{totalCast}</strong></span>
          <span className="text-purple-900 font-bold">{countFavor} Fav · {countContra} Con · {countAbstencion} Abs</span>
        </div>

        <div className="w-full h-1.5 bg-slate-100 rounded-full flex overflow-hidden">
          <div 
            style={{ width: `${totalCast > 0 ? (countFavor / totalCast) * 100 : 0}%` }}
            className="bg-[#4A154B] h-full transition-all duration-300"
          />
          <div 
            style={{ width: `${totalCast > 0 ? (countContra / totalCast) * 100 : 0}%` }}
            className="bg-rose-600 h-full transition-all duration-300"
          />
          <div 
            style={{ width: `${totalCast > 0 ? (countAbstencion / totalCast) * 100 : 0}%` }}
            className="bg-slate-400 h-full transition-all duration-300"
          />
        </div>

        {/* Mesa Directiva / Secretaria Tecnica Close / Reopen */}
        {(isDireccionNacional || isSecretariaTecnica) && (
          <div className="mt-2">
            {activeMotion.status === 'VOTING' ? (
              <button
                onClick={() => closeVotingForMotion(activeMotion.id)}
                className="w-full py-1 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded-lg font-bold text-[10px] shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Lock className="w-3 h-3" />
                <span>Cerrar Votación y Escrutar</span>
              </button>
            ) : (
              <button
                onClick={() => openVotingForMotion(activeMotion.id)}
                className="w-full py-1 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-bold text-[10px] transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reabrir Votación</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Modal: Lanzar Nueva Votación */}
      {showLaunchModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-5 shadow-2xl text-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-200 mb-3">
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                <Vote className="w-4 h-4 text-[#4A154B]" />
                <span>Lanzar Votación Oficial</span>
              </h3>
              <button onClick={() => setShowLaunchModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleLaunchSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Título de la Moción</label>
                <input
                  type="text"
                  required
                  value={launchTitle}
                  onChange={(e) => setLaunchTitle(e.target.value)}
                  placeholder="Ej: Moción de financiamiento basal universitario"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Inciso Resolutivo a Votar</label>
                <textarea
                  rows={2}
                  required
                  value={launchDesc}
                  onChange={(e) => setLaunchDesc(e.target.value)}
                  placeholder="Detalle el contenido de la moción..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Régimen de Quórum</label>
                <select
                  value={launchQuorum}
                  onChange={(e) => setLaunchQuorum(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900"
                >
                  <option value="SIMPLE_MAJORITY">Mayoría Simple (50%+1)</option>
                  <option value="TWO_THIRDS">Dos Tercios (2/3)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowLaunchModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-xs font-bold rounded-xl shadow cursor-pointer"
                >
                  Lanzar a Sala
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
