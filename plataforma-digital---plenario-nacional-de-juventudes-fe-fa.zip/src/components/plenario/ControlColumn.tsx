import React, { useState } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  Vote, 
  CheckCircle2, 
  XCircle, 
  MinusCircle, 
  Send, 
  MessageSquare, 
  ShieldCheck, 
  Check, 
  X, 
  TrendingUp, 
  Clock, 
  Lock,
  RotateCcw,
  Plus,
  Radio,
  FileCheck2,
  ChevronDown,
  Layers
} from 'lucide-react';
import { OrderMotionCategory } from '../../types/plenario';

export const ControlColumn: React.FC = () => {
  const { 
    currentUser, 
    activeMotion, 
    activeMotionId,
    setActiveMotionId,
    motionsHistory,
    castVote, 
    closeVotingForMotion, 
    openVotingForMotion,
    createNewMotion,
    orderMotions, 
    sendOrderMotion, 
    resolveOrderMotion,
    setActiveTab,
    isDireccionNacional,
    isDelegate
  } = usePlenario();

  const [activeSubTab, setActiveSubTab] = useState<'VOTACION' | 'ORDEN'>('VOTACION');
  const [showLaunchModal, setShowLaunchModal] = useState(false);
  const [launchTitle, setLaunchTitle] = useState('');
  const [launchDesc, setLaunchDesc] = useState('');
  const [launchQuorum, setLaunchQuorum] = useState<'SIMPLE_MAJORITY' | 'TWO_THIRDS'>('SIMPLE_MAJORITY');
  const [immediateLaunch, setImmediateLaunch] = useState(true);

  const [message, setMessage] = useState('');
  const [category, setCategory] = useState<OrderMotionCategory>('MOCION_ORDEN');
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'MOCIONES' | 'AYUDA'>('ALL');

  const hasVoted = currentUser && !!activeMotion.votes[currentUser.id];
  const userVote = currentUser ? activeMotion.votes[currentUser.id] : null;

  // Tally counts
  const votesArray = Object.values(activeMotion.votes);
  const countFavor = votesArray.filter(v => v.vote === 'A_FAVOR').length;
  const countContra = votesArray.filter(v => v.vote === 'EN_CONTRA').length;
  const countAbstencion = votesArray.filter(v => v.vote === 'ABSTENCION').length;
  const totalCast = votesArray.length;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendOrderMotion(category, message.trim());
    setMessage('');
  };

  const handleLaunchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!launchTitle.trim()) return;
    createNewMotion(launchTitle.trim(), launchDesc.trim(), launchQuorum, immediateLaunch);
    setLaunchTitle('');
    setLaunchDesc('');
    setShowLaunchModal(false);
    setActiveSubTab('VOTACION');
  };

  const getCategoryLabel = (cat: OrderMotionCategory) => {
    switch (cat) {
      case 'MOCION_ORDEN': return 'Moción de Orden';
      case 'PUNTO_INFORMACION': return 'Punto de Información';
      case 'CUESTION_PREVIA': return 'Cuestión Previa';
      case 'MOCION_CENSURA': return 'Moción de Censura';
      case 'MESA_AYUDA': return 'Mesa de Ayuda';
    }
  };

  const filteredOrderMotions = orderMotions.filter(item => {
    if (selectedFilter === 'MOCIONES') return item.category !== 'MESA_AYUDA';
    if (selectedFilter === 'AYUDA') return item.category === 'MESA_AYUDA';
    return true;
  });

  return (
    <div className="flex flex-col h-full w-full min-w-0 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
      
      {/* Top Header with Tab Switcher & Directiva Launch Button */}
      <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1 bg-white p-0.5 rounded-xl border border-slate-200 shadow-xs">
          <button
            onClick={() => setActiveSubTab('VOTACION')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'VOTACION'
                ? 'bg-[#4A154B] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Vote className="w-3.5 h-3.5" />
            <span>Cabina de Votación</span>
            {activeMotion.status === 'VOTING' && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse ml-0.5" />
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('ORDEN')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'ORDEN'
                ? 'bg-[#4A154B] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Mociones de Orden</span>
            {orderMotions.some(o => o.status === 'PENDIENTE') && (
              <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px] font-mono">
                {orderMotions.filter(o => o.status === 'PENDIENTE').length}
              </span>
            )}
          </button>
        </div>

        {/* Directiva Quick Launch Voting Button */}
        {isDireccionNacional && (
          <button
            onClick={() => setShowLaunchModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white rounded-xl text-xs font-bold shadow-xs hover:brightness-110 transition-all cursor-pointer shrink-0"
            title="Lanzar una nueva votación formal para toda la sala"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Lanzar Votación</span>
          </button>
        )}
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
        
        {activeSubTab === 'VOTACION' && (
          <div className="space-y-3.5">
            
            {/* Motion Selector & Status Badge */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {motionsHistory.length > 1 ? (
                    <select
                      value={activeMotionId}
                      onChange={(e) => setActiveMotionId(e.target.value)}
                      className="text-xs font-mono font-bold text-purple-900 bg-purple-50 border border-purple-200 rounded-lg px-2 py-0.5 focus:outline-none cursor-pointer"
                    >
                      {motionsHistory.map(m => (
                        <option key={m.id} value={m.id}>
                          {m.code} · {m.status === 'VOTING' ? '● En Votación' : m.status === 'APPROVED' ? '✓ Aprobada' : m.status}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className="text-xs font-mono font-bold text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                      {activeMotion.code}
                    </span>
                  )}

                  <span className="text-[11px] text-slate-500 font-medium">
                    {activeMotion.quorumType === 'TWO_THIRDS' ? 'Quórum 2/3' : 'Mayoría Simple (50%+1)'}
                  </span>
                </div>

                <h3 className="text-sm font-extrabold text-slate-900 leading-snug">
                  {activeMotion.title}
                </h3>
              </div>

              <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider shrink-0 ${
                activeMotion.status === 'VOTING' 
                  ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse' 
                  : activeMotion.status === 'APPROVED' 
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                    : 'bg-slate-100 text-slate-700 border border-slate-300'
              }`}>
                {activeMotion.status === 'VOTING' ? '● Votación Abierta' : activeMotion.status === 'APPROVED' ? '✓ Aprobada' : 'Cerrada'}
              </span>
            </div>

            {/* Description */}
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              {activeMotion.description}
            </p>

            {/* Action Voting Area */}
            {activeMotion.status === 'VOTING' ? (
              <div className="space-y-3">
                
                {isDireccionNacional ? (
                  /* Dirección Nacional: Conduce y modera, pero no vota */
                  <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 text-xs">
                    <div className="flex items-center gap-1.5 font-bold text-purple-900 mb-1">
                      <ShieldCheck className="w-4 h-4 text-purple-800 shrink-0" />
                      <span>Mesa Directiva: Conducción y Escrutinio</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      La Dirección Nacional cuenta con <strong>derecho a voz</strong> para orientar el debate pero <strong>no emite voto</strong>, resguardando la soberanía de las y los delegados regionales acreditados.
                    </p>
                  </div>
                ) : isDelegate ? (
                  /* Regional Voting Delegate: Voice and Vote, allows rectifying */
                  <div className="space-y-2.5">
                    
                    {hasVoted ? (
                      <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-300 text-xs flex flex-col gap-1">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-purple-950 font-bold">
                            <CheckCircle2 className="w-4 h-4 text-purple-800" />
                            <span>Voto emitido y verificado</span>
                          </span>
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-black shadow-xs ${
                            userVote?.vote === 'A_FAVOR' 
                              ? 'bg-[#4A154B] text-white' 
                              : userVote?.vote === 'EN_CONTRA' 
                                ? 'bg-rose-600 text-white' 
                                : 'bg-slate-700 text-white'
                          }`}>
                            {userVote?.vote === 'A_FAVOR' ? 'A FAVOR' : userVote?.vote === 'EN_CONTRA' ? 'EN CONTRA' : 'ABSTENCIÓN'}
                          </span>
                        </div>
                        <p className="text-[11px] text-purple-900/80">
                          Puede <strong>rectificar su voto</strong> antes del cierre oficial seleccionando otra opción:
                        </p>
                      </div>
                    ) : (
                      <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Vote className="w-4 h-4 text-[#4A154B]" />
                        <span>Emita su voto nominal (1 persona = 1 voto):</span>
                      </div>
                    )}

                    {/* 3 Prominent High-Contrast Voting Buttons */}
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => castVote('A_FAVOR')}
                        className={`py-3 px-2 rounded-xl text-xs font-bold shadow-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer active:scale-95 border-2 ${
                          userVote?.vote === 'A_FAVOR'
                            ? 'bg-[#4A154B] text-white border-purple-900 ring-3 ring-purple-200'
                            : 'bg-purple-50 hover:bg-[#4A154B] text-[#4A154B] hover:text-white border-purple-200'
                        }`}
                      >
                        <CheckCircle2 className={`w-5 h-5 ${userVote?.vote === 'A_FAVOR' ? 'text-white' : 'text-[#4A154B]'}`} />
                        <span className="tracking-wide">A FAVOR</span>
                        {userVote?.vote === 'A_FAVOR' && (
                          <span className="text-[9px] bg-purple-900 text-white px-1.5 py-0.2 rounded font-mono">
                            Su Voto ✓
                          </span>
                        )}
                      </button>

                      <button
                        onClick={() => castVote('EN_CONTRA')}
                        className={`py-3 px-2 rounded-xl text-xs font-bold shadow-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer active:scale-95 border-2 ${
                          userVote?.vote === 'EN_CONTRA'
                            ? 'bg-rose-600 text-white border-rose-800 ring-3 ring-rose-200'
                            : 'bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border-rose-200'
                        }`}
                      >
                        <XCircle className={`w-5 h-5 ${userVote?.vote === 'EN_CONTRA' ? 'text-white' : 'text-rose-600'}`} />
                        <span className="tracking-wide">EN CONTRA</span>
                        {userVote?.vote === 'EN_CONTRA' && (
                          <span className="text-[9px] bg-rose-800 text-white px-1.5 py-0.2 rounded font-mono">
                            Su Voto ✓
                          </span>
                        )}
                      </button>

                      <button
                        onClick={() => castVote('ABSTENCION')}
                        className={`py-3 px-2 rounded-xl text-xs font-bold shadow-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer active:scale-95 border-2 ${
                          userVote?.vote === 'ABSTENCION'
                            ? 'bg-slate-700 text-white border-slate-900 ring-3 ring-slate-200'
                            : 'bg-slate-100 hover:bg-slate-700 text-slate-700 hover:text-white border-slate-300'
                        }`}
                      >
                        <MinusCircle className={`w-5 h-5 ${userVote?.vote === 'ABSTENCION' ? 'text-white' : 'text-slate-600'}`} />
                        <span className="tracking-wide">ABSTENCIÓN</span>
                        {userVote?.vote === 'ABSTENCION' && (
                          <span className="text-[9px] bg-slate-900 text-white px-1.5 py-0.2 rounded font-mono">
                            Su Voto ✓
                          </span>
                        )}
                      </button>
                    </div>

                    {hasVoted && (
                      <div className="text-[10px] text-slate-500 font-mono text-center truncate pt-0.5">
                        Firma criptográfica: {userVote?.digitalSignatureHash}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-3 text-center text-xs text-slate-600 bg-slate-100 rounded-xl">
                    Debe estar acreditada/o con credencial telemática para emitir voto nominal.
                  </div>
                )}
              </div>
            ) : (
              <div className="p-3 bg-slate-100 rounded-xl border border-slate-200 text-center text-xs text-slate-700 font-semibold">
                {activeMotion.status === 'APPROVED' ? '✓ Moción aprobada formalmente por el Plenario.' : 'Votación concluida.'}
              </div>
            )}

            {/* Real-time Tally Progress Strip */}
            <div className="pt-3 border-t border-slate-200">
              <div className="flex items-center justify-between text-xs font-mono text-slate-600 mb-2">
                <span>Votos emitidos: <strong className="text-slate-900 font-bold">{totalCast}</strong></span>
                <button 
                  onClick={() => setActiveTab('plenario')}
                  className="text-[#4A154B] hover:underline flex items-center gap-1 font-bold text-xs"
                >
                  <span>Hemiciclo en vivo</span>
                  <TrendingUp className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="w-full h-2.5 bg-slate-100 border border-slate-200 rounded-full flex overflow-hidden">
                <div 
                  style={{ width: `${totalCast > 0 ? (countFavor / totalCast) * 100 : 0}%` }}
                  className="bg-[#4A154B] h-full transition-all duration-300"
                  title={`A Favor: ${countFavor}`}
                />
                <div 
                  style={{ width: `${totalCast > 0 ? (countContra / totalCast) * 100 : 0}%` }}
                  className="bg-rose-600 h-full transition-all duration-300"
                  title={`En Contra: ${countContra}`}
                />
                <div 
                  style={{ width: `${totalCast > 0 ? (countAbstencion / totalCast) * 100 : 0}%` }}
                  className="bg-slate-400 h-full transition-all duration-300"
                  title={`Abstención: ${countAbstencion}`}
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-600 mt-2 font-mono">
                <span className="text-purple-900 font-bold">{countFavor} A Favor ({totalCast > 0 ? Math.round((countFavor / totalCast) * 100) : 0}%)</span>
                <span className="text-rose-700 font-bold">{countContra} En Contra</span>
                <span className="text-slate-600 font-bold">{countAbstencion} Abst.</span>
              </div>
            </div>

            {/* Directiva Exclusive Actions */}
            {isDireccionNacional && (
              <div className="pt-2 border-t border-slate-200">
                {activeMotion.status === 'VOTING' ? (
                  <button
                    onClick={() => closeVotingForMotion(activeMotion.id)}
                    className="w-full py-2.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded-xl font-bold text-xs shadow transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                  >
                    <Lock className="w-4 h-4 text-purple-200" />
                    <span>Cerrar Votación y Escrutar Oficialmente</span>
                  </button>
                ) : (
                  <button
                    onClick={() => openVotingForMotion(activeMotion.id)}
                    className="w-full py-2 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white rounded-xl font-bold text-xs shadow transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Reabrir Votación</span>
                  </button>
                )}
              </div>
            )}

          </div>
        )}

        {/* Tab 2: Mociones de Orden */}
        {activeSubTab === 'ORDEN' && (
          <div className="flex flex-col h-full space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">Filtrar Canal:</span>
              <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-xl border border-slate-200">
                <button
                  onClick={() => setSelectedFilter('ALL')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                    selectedFilter === 'ALL' ? 'bg-[#4A154B] text-white' : 'text-slate-600'
                  }`}
                >
                  Todas
                </button>
                <button
                  onClick={() => setSelectedFilter('MOCIONES')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                    selectedFilter === 'MOCIONES' ? 'bg-[#4A154B] text-white' : 'text-slate-600'
                  }`}
                >
                  Mociones
                </button>
                <button
                  onClick={() => setSelectedFilter('AYUDA')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                    selectedFilter === 'AYUDA' ? 'bg-[#4A154B] text-white' : 'text-slate-600'
                  }`}
                >
                  Ayuda
                </button>
              </div>
            </div>

            {/* List */}
            <div className="space-y-2 flex-1 max-h-64 overflow-y-auto pr-1">
              {filteredOrderMotions.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No hay mensajes registrados.
                </div>
              ) : (
                filteredOrderMotions.map(om => (
                  <div 
                    key={om.id}
                    className={`p-2.5 rounded-xl border text-xs ${
                      om.category === 'MESA_AYUDA' ? 'bg-blue-50/70 border-blue-200' : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          om.category === 'MESA_AYUDA' ? 'bg-blue-600 text-white' : 'bg-[#4A154B] text-white'
                        }`}>
                          {getCategoryLabel(om.category)}
                        </span>
                        <span className="font-bold text-slate-800 truncate max-w-[130px]">
                          {om.delegateName}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(om.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <p className="text-slate-700 text-xs leading-relaxed my-1">
                      {om.message}
                    </p>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/80 mt-1">
                      <span className={`text-[10px] font-semibold ${
                        om.status === 'ATENDIDA' ? 'text-emerald-700' : 'text-amber-700'
                      }`}>
                        {om.status === 'ATENDIDA' ? `✓ Atendida (${om.resolvedBy})` : '• Pendiente'}
                      </span>

                      {isDireccionNacional && om.status === 'PENDIENTE' && (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => resolveOrderMotion(om.id, 'ATENDIDA')}
                            className="p-1 rounded bg-emerald-100 hover:bg-emerald-200 text-emerald-800 text-[10px] flex items-center gap-0.5 font-bold cursor-pointer"
                          >
                            <Check className="w-3 h-3" />
                            <span>Atender</span>
                          </button>
                          <button
                            onClick={() => resolveOrderMotion(om.id, 'DESESTIMADA')}
                            className="p-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] cursor-pointer"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Input */}
            <form onSubmit={handleSendMessage} className="pt-2 border-t border-slate-200 space-y-2">
              <div className="flex items-center gap-1.5">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as OrderMotionCategory)}
                  className="bg-white border border-slate-300 rounded-xl px-2 py-1.5 text-[11px] text-slate-800 font-medium focus:outline-none focus:border-[#4A154B] shrink-0"
                >
                  <option value="MOCION_ORDEN">Moción de Orden</option>
                  <option value="PUNTO_INFORMACION">Punto de Información</option>
                  <option value="CUESTION_PREVIA">Cuestión Previa</option>
                  <option value="MOCION_CENSURA">Moción de Censura</option>
                  <option value="MESA_AYUDA">Mesa de Ayuda</option>
                </select>

                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Escriba su moción a la Mesa..."
                  className="flex-1 bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-[#4A154B]"
                />

                <button
                  type="submit"
                  disabled={!message.trim()}
                  className="p-2 bg-[#4A154B] hover:bg-[#5E1B5F] disabled:opacity-40 text-white rounded-xl transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </div>
        )}

      </div>

      {/* Modal: Lanzar Nueva Votación Oficial (Dirección Nacional) */}
      {showLaunchModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg p-6 shadow-2xl text-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-[#4A154B] text-white">
                  <Vote className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Lanzar Nueva Votación Oficial
                  </h3>
                  <span className="text-xs text-purple-900 font-medium">
                    Atribución Exclusiva de la Dirección Nacional
                  </span>
                </div>
              </div>
              <button 
                onClick={() => setShowLaunchModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleLaunchSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Título de la Moción / Artículo
                </label>
                <input
                  type="text"
                  required
                  value={launchTitle}
                  onChange={(e) => setLaunchTitle(e.target.value)}
                  placeholder="Ej: Aprobación de la Enmienda N° 4 sobre Aranceles Regulados y Basales"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B] focus:bg-white font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Texto Resolutivo o Inciso a Votar
                </label>
                <textarea
                  rows={3}
                  required
                  value={launchDesc}
                  onChange={(e) => setLaunchDesc(e.target.value)}
                  placeholder="Redacte el texto exacto sobre el cual las delegadas y delegados emitirán su voto nominal..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Quórum Estatutario Requerido
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setLaunchQuorum('SIMPLE_MAJORITY')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex flex-col items-start ${
                      launchQuorum === 'SIMPLE_MAJORITY'
                        ? 'bg-purple-50 border-purple-400 text-purple-900 ring-2 ring-purple-200'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span>Mayoría Simple (50%+1)</span>
                    <span className="text-[10px] text-slate-500 font-normal mt-0.5">Mociones ordinarias y de sala</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setLaunchQuorum('TWO_THIRDS')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex flex-col items-start ${
                      launchQuorum === 'TWO_THIRDS'
                        ? 'bg-purple-50 border-purple-400 text-purple-900 ring-2 ring-purple-200'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span>Dos Tercios (2/3)</span>
                    <span className="text-[10px] text-slate-500 font-normal mt-0.5">Estatutos y acuerdos de fondo</span>
                  </button>
                </div>
              </div>

              <div className="p-3 bg-purple-50/60 border border-purple-200 rounded-xl flex items-center gap-2">
                <input 
                  type="checkbox"
                  id="immediateLaunch"
                  checked={immediateLaunch}
                  onChange={(e) => setImmediateLaunch(e.target.checked)}
                  className="rounded text-[#4A154B] focus:ring-[#4A154B] h-4 w-4 cursor-pointer"
                />
                <label htmlFor="immediateLaunch" className="text-xs font-semibold text-purple-950 cursor-pointer">
                  Lanzar inmediatamente a toda la sala (abre la cabina de votación en tiempo real)
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowLaunchModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] hover:brightness-110 text-white text-xs font-bold rounded-xl shadow cursor-pointer transition-all"
                >
                  {immediateLaunch ? 'Lanzar Votación Inmediata' : 'Crear Moción'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
