import React, { useState, useRef, useEffect, useMemo } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  Camera, 
  CameraOff,
  Image as ImageIcon, 
  Mic, 
  MicOff, 
  Radio, 
  UserCheck, 
  VolumeX,
  Volume2,
  LayoutGrid,
  Maximize2,
  Minimize2,
  Monitor,
  MonitorOff,
  Sparkles,
  Smile,
  Shield,
  Wifi,
  WifiOff,
  Pin,
  Settings,
  MoreVertical,
  Sliders,
  Check
} from 'lucide-react';
import { Delegate } from '../../types/plenario';

type VideoViewMode = 'SPOTLIGHT' | 'GRID' | 'SCREEN';

interface FloatingReaction {
  id: string;
  emoji: string;
  senderName: string;
  x: number;
}

export const VideoBox: React.FC = () => {
  const { 
    currentUser, 
    activeSpeaker, 
    timerSeconds, 
    isTimerRunning,
    lowBandwidthMode, 
    setLowBandwidthMode,
    forceMuted,
    setForceMuted,
    isDireccionNacional,
    isSecretariaTecnica,
    delegates
  } = usePlenario();

  // Media States
  const [useRealWebcam, setUseRealWebcam] = useState(false);
  const [isMicOn, setIsMicOn] = useState(false);
  const [isSharingScreen, setIsSharingScreen] = useState(false);
  const [viewMode, setViewMode] = useState<VideoViewMode>('SPOTLIGHT');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [volume, setVolume] = useState(85);
  const [isDeafened, setIsDeafened] = useState(false);
  const [virtualBg, setVirtualBg] = useState<'NONE' | 'BLUR' | 'CONGRESO'>('NONE');
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);

  // Floating Reactions state
  const [reactions, setReactions] = useState<FloatingReaction[]>([]);
  const [showReactionPicker, setShowReactionPicker] = useState(false);

  // Spotlight override (allow manual pinning from grid)
  const [pinnedDelegateId, setPinnedDelegateId] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const screenVideoRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);

  // Real Webcam Handling
  useEffect(() => {
    if (useRealWebcam) {
      navigator.mediaDevices?.getUserMedia({ 
        video: { width: { ideal: 1280 }, height: { ideal: 720 } }, 
        audio: true 
      })
        .then(stream => {
          mediaStreamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
          setIsMicOn(true);
        })
        .catch(err => {
          console.warn('Webcam permission not granted:', err);
          setUseRealWebcam(false);
        });
    } else {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
    }
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [useRealWebcam]);

  // Screen Sharing Handling
  const handleToggleScreenShare = async () => {
    if (isSharingScreen) {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
        screenStreamRef.current = null;
      }
      setIsSharingScreen(false);
      setViewMode('SPOTLIGHT');
    } else {
      try {
        if (navigator.mediaDevices && 'getDisplayMedia' in navigator.mediaDevices) {
          const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          screenStreamRef.current = stream;
          if (screenVideoRef.current) {
            screenVideoRef.current.srcObject = stream;
          }
          setIsSharingScreen(true);
          setViewMode('SCREEN');
          stream.getVideoTracks()[0].onended = () => {
            setIsSharingScreen(false);
            setViewMode('SPOTLIGHT');
          };
        } else {
          // Simulation fallback for presentations
          setIsSharingScreen(true);
          setViewMode('SCREEN');
        }
      } catch (err) {
        console.warn('Screen share canceled:', err);
        setIsSharingScreen(false);
      }
    }
  };

  // Simulated Audio Waveform Activity
  useEffect(() => {
    let animFrame: number;
    if ((isMicOn || isTimerRunning) && !forceMuted) {
      const updateLevel = () => {
        // Random natural voice cadence
        const base = Math.sin(Date.now() / 150) * 0.4 + 0.5;
        const randomSpike = Math.random() > 0.7 ? Math.random() * 0.4 : 0;
        setAudioLevel(Math.min(1, Math.max(0.1, base + randomSpike)));
        animFrame = requestAnimationFrame(updateLevel);
      };
      animFrame = requestAnimationFrame(updateLevel);
    } else {
      setAudioLevel(0);
    }
    return () => cancelAnimationFrame(animFrame);
  }, [isMicOn, isTimerRunning, forceMuted]);

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Add Reaction
  const sendReaction = (emoji: string) => {
    const newReaction: FloatingReaction = {
      id: `react-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      emoji,
      senderName: currentUser ? currentUser.name : 'Delegado',
      x: 20 + Math.random() * 60
    };
    setReactions(prev => [...prev.slice(-12), newReaction]);
    setShowReactionPicker(false);
    setTimeout(() => {
      setReactions(prev => prev.filter(r => r.id !== newReaction.id));
    }, 2800);
  };

  const isCriticalTime = timerSeconds <= 20 && timerSeconds > 0;

  // Delegates for grid view (limit to active online delegates)
  const gridDelegates = useMemo(() => {
    const online = delegates.filter(d => d.isOnline).slice(0, 8);
    return online;
  }, [delegates]);

  // Current featured delegate
  const featuredDelegate = useMemo(() => {
    if (pinnedDelegateId) {
      const match = delegates.find(d => d.id === pinnedDelegateId);
      if (match) return match;
    }
    if (activeSpeaker) {
      const match = delegates.find(d => d.id === activeSpeaker.delegateId);
      if (match) return match;
    }
    return delegates[0] || null;
  }, [pinnedDelegateId, activeSpeaker, delegates]);

  return (
    <div 
      ref={containerRef}
      className="relative rounded-2xl bg-slate-950 border border-slate-300 overflow-hidden shadow-md h-full w-full min-w-0 flex flex-col justify-between select-none group"
    >
      
      {/* 1. TOP OVERLAY BAR: Streaming Status, Modes, Prototype Cutouts [CAM] and [IMG] */}
      <div className="absolute top-0 inset-x-0 p-3 bg-gradient-to-b from-black/85 via-black/50 to-transparent z-30 flex items-center justify-between pointer-events-auto">
        
        {/* Left tags: Live WebRTC, Resolution, Latency */}
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-600/90 text-white text-[10px] font-bold tracking-wide uppercase shadow backdrop-blur-xs">
            <Radio className="w-3 h-3 animate-pulse text-white" />
            <span>EN VIVO · WebRTC HD</span>
          </span>

          {lowBandwidthMode ? (
            <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black shadow-xs">
              <WifiOff className="w-3 h-3" />
              <span>Modo Audio / 32kbps</span>
            </span>
          ) : (
            <span className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono">
              <Wifi className="w-3 h-3 text-emerald-400" />
              <span>1080p · 24ms</span>
            </span>
          )}

          {forceMuted && (
            <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-950/90 text-rose-300 border border-rose-500/40 text-[10px] font-bold">
              <VolumeX className="w-3 h-3" />
              <span>Sala Silenciada</span>
            </span>
          )}
        </div>

        {/* Right tags: View Mode Switcher, Paper Prototype Cutouts [ CAM ] and [ IMG ] */}
        <div className="flex items-center gap-1.5 bg-black/60 p-1 rounded-xl backdrop-blur-md border border-white/10 shadow-lg">
          
          {/* Layout Mode Switcher */}
          <div className="flex items-center bg-white/10 rounded-lg p-0.5 mr-1">
            <button
              onClick={() => setViewMode('SPOTLIGHT')}
              className={`p-1 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                viewMode === 'SPOTLIGHT' ? 'bg-[#4A154B] text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
              title="Modo Orador Central (Spotlight)"
            >
              Foco
            </button>
            <button
              onClick={() => setViewMode('GRID')}
              className={`p-1 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                viewMode === 'GRID' ? 'bg-[#4A154B] text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
              title="Modo Mosaico (Galería de Delegaciones)"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleToggleScreenShare}
              className={`p-1 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                viewMode === 'SCREEN' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
              title="Compartir Pantalla / Documento"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Prototype Cutout [ CAM ] */}
          <button
            onClick={() => setUseRealWebcam(!useRealWebcam)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
              useRealWebcam 
                ? 'bg-[#4A154B] text-white shadow-sm ring-1 ring-purple-300' 
                : 'bg-white/10 text-white/90 hover:bg-white/20'
            }`}
            title="Activar cámara web real del dispositivo"
          >
            {useRealWebcam ? <Camera className="w-3.5 h-3.5 text-emerald-300" /> : <CameraOff className="w-3.5 h-3.5" />}
            <span>CAM</span>
          </button>

          {/* Prototype Cutout [ IMG ] */}
          <button
            onClick={() => setLowBandwidthMode(!lowBandwidthMode)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
              lowBandwidthMode 
                ? 'bg-amber-500 text-black shadow-xs font-black ring-1 ring-amber-300' 
                : 'bg-white/10 text-white/90 hover:bg-white/20'
            }`}
            title="Modo IMG: Reducción de consumo y avatar fijo"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>IMG</span>
          </button>

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Pantalla Completa"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

        </div>
      </div>

      {/* 2. MAIN BROADCAST VIEWPORT */}
      <div className="relative flex-1 flex items-center justify-center w-full h-full bg-[#0A0D14] overflow-hidden">
        
        {/* Low Bandwidth Mode (Audio only + Avatars) */}
        {lowBandwidthMode ? (
          <div className="flex flex-col items-center justify-center p-6 text-center z-10 animate-in fade-in duration-200">
            <div className="relative mb-3">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#4A154B] to-[#D32F2F] flex items-center justify-center text-4xl font-black text-white shadow-2xl ring-4 ring-purple-500/30">
                {activeSpeaker ? activeSpeaker.delegateName.charAt(0) : 'FA'}
              </div>
              {/* Dynamic pulse ring based on audio level */}
              <div 
                style={{ transform: `scale(${1 + audioLevel * 0.25})`, opacity: audioLevel }}
                className="absolute inset-0 rounded-full border-2 border-emerald-400 transition-transform duration-75"
              />
            </div>

            <div className="text-white font-extrabold text-base tracking-tight">
              {activeSpeaker ? activeSpeaker.delegateName : 'Plenario Nacional FE-FA en Deliberación'}
            </div>
            <div className="text-xs text-purple-200 font-medium mt-0.5">
              {activeSpeaker ? `Bancada Regional: ${activeSpeaker.region}` : 'Mesa Directiva Conduciendo la Sesión'}
            </div>
            
            <div className="mt-3 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-[11px] font-mono flex items-center gap-1.5">
              <WifiOff className="w-3 h-3 text-amber-400" />
              <span>Modo IMG Activo · Audio estéreo cristalino prioritario</span>
            </div>
          </div>
        ) : viewMode === 'SCREEN' ? (
          /* Presentation / Screen Share View */
          <div className="relative w-full h-full flex flex-col items-center justify-center bg-slate-900 p-2">
            {screenStreamRef.current ? (
              <video 
                ref={screenVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-contain rounded-xl shadow-2xl"
              />
            ) : (
              <div className="w-full h-full bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center text-center">
                <Monitor className="w-12 h-12 text-purple-400 mb-3 animate-pulse" />
                <h4 className="text-white font-bold text-sm">Presentación del Documento de Síntesis Nacional</h4>
                <p className="text-xs text-slate-400 max-w-md mt-1">
                  Transmisión compartida del texto oficial de debate e indicaciones para el Plenario.
                </p>
                <div className="mt-4 px-4 py-2 bg-[#4A154B] text-white rounded-xl text-xs font-bold shadow">
                  Proyección en Sala Oficial
                </div>
              </div>
            )}

            {/* Pinned Speaker PiP Overlay */}
            <div className="absolute bottom-16 right-4 w-44 bg-slate-950/90 border border-purple-500/50 rounded-xl p-2 shadow-2xl z-20 backdrop-blur-md">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#4A154B] to-[#D32F2F] flex items-center justify-center text-xs font-bold text-white shrink-0 overflow-hidden">
                  {featuredDelegate?.avatarUrl ? (
                    <img src={featuredDelegate.avatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    featuredDelegate?.name.charAt(0) || 'D'
                  )}
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-white truncate">{featuredDelegate?.name}</div>
                  <div className="text-[9px] text-purple-300 font-mono truncate">{featuredDelegate?.region}</div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-[9px] text-emerald-300 font-bold">Orador en Vivo</span>
              </div>
            </div>
          </div>
        ) : viewMode === 'GRID' ? (
          /* Mosaic / Gallery Grid Mode */
          <div className="w-full h-full p-4 grid grid-cols-2 md:grid-cols-4 gap-2.5 overflow-y-auto">
            {gridDelegates.map((d: Delegate) => {
              const isSpeakingNow = activeSpeaker?.delegateId === d.id;
              const isPinned = pinnedDelegateId === d.id;

              return (
                <div
                  key={d.id}
                  onClick={() => {
                    setPinnedDelegateId(isPinned ? null : d.id);
                    setViewMode('SPOTLIGHT');
                  }}
                  className={`relative rounded-xl overflow-hidden bg-slate-900 border transition-all cursor-pointer flex flex-col justify-between p-2 shadow group/card ${
                    isSpeakingNow
                      ? 'border-emerald-400 ring-2 ring-emerald-400/40 bg-emerald-950/20'
                      : isPinned
                        ? 'border-purple-400 ring-2 ring-purple-400/40'
                        : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <div className="flex items-center justify-between z-10">
                    <span className="px-1.5 py-0.5 rounded bg-black/60 text-[9px] font-mono text-purple-200">
                      {d.region}
                    </span>
                    {isSpeakingNow && (
                      <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 text-[9px] font-black">
                        <Mic className="w-2.5 h-2.5" /> Habla
                      </span>
                    )}
                  </div>

                  <div className="flex flex-col items-center justify-center my-auto py-2">
                    <div className="relative">
                      <div className="w-14 h-14 rounded-full overflow-hidden border border-white/20 shadow-md">
                        {d.avatarUrl ? (
                          <img src={d.avatarUrl} alt={d.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-tr from-[#4A154B] to-[#D32F2F] flex items-center justify-center text-white font-bold text-lg">
                            {d.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      {isSpeakingNow && (
                        <div 
                          style={{ transform: `scale(${1 + audioLevel * 0.3})` }}
                          className="absolute inset-0 rounded-full border-2 border-emerald-400 pointer-events-none transition-transform duration-75"
                        />
                      )}
                    </div>
                  </div>

                  <div className="z-10 flex items-center justify-between text-left">
                    <div className="truncate">
                      <div className="text-[11px] font-bold text-white truncate">{d.name}</div>
                      <div className="text-[9px] text-slate-400 truncate">{d.organization}</div>
                    </div>
                    <Pin className={`w-3 h-3 transition-opacity ${isPinned ? 'text-purple-400 opacity-100' : 'text-slate-500 opacity-0 group-hover/card:opacity-100'}`} />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* Spotlight / Featured Speaker Mode (Default & Primary Parliamentary Feed) */
          <div className="relative w-full h-full flex items-center justify-center">
            {useRealWebcam ? (
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className={`w-full h-full object-cover transform -scale-x-100 ${
                  virtualBg === 'BLUR' ? 'filter blur-[1px]' : ''
                }`}
              />
            ) : (
              <div className="relative w-full h-full flex items-center justify-center bg-radial from-[#2a133d] via-[#121422] to-[#07090f]">
                {/* Visual Ambient Lighting Rings */}
                <div 
                  style={{ transform: `scale(${1 + audioLevel * 0.15})` }}
                  className="absolute w-[340px] h-[340px] rounded-full bg-gradient-to-tr from-[#4A154B]/30 to-[#D32F2F]/20 blur-3xl pointer-events-none transition-transform duration-100"
                />

                <div className="relative z-10 flex flex-col items-center p-4">
                  
                  {/* Speaker Card Avatar with Parity & Critical Timer Aura */}
                  <div className="relative mb-3">
                    <div className={`w-32 h-32 rounded-3xl overflow-hidden border-2 shadow-2xl transition-all duration-300 ${
                      isCriticalTime 
                        ? 'border-rose-500 ring-8 ring-rose-500/30 animate-pulse' 
                        : isTimerRunning
                          ? 'border-purple-400 ring-4 ring-purple-500/20'
                          : 'border-slate-700'
                    }`}>
                      {featuredDelegate?.avatarUrl ? (
                        <img 
                          src={featuredDelegate.avatarUrl} 
                          alt={featuredDelegate.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-tr from-[#4A154B] to-[#D32F2F] flex items-center justify-center text-4xl font-black text-white">
                          {featuredDelegate?.name.charAt(0) || 'FA'}
                        </div>
                      )}
                    </div>

                    {/* Audio Waveform Bounce Pill on Speaker */}
                    {isTimerRunning && (
                      <div className="absolute -bottom-2.5 inset-x-0 mx-auto w-20 bg-slate-950/95 border border-purple-400/50 rounded-full py-0.5 px-2 flex items-center justify-center gap-1 shadow-lg backdrop-blur-xs">
                        <span 
                          style={{ height: `${Math.max(4, audioLevel * 14)}px` }}
                          className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                        />
                        <span 
                          style={{ height: `${Math.max(6, audioLevel * 18)}px` }}
                          className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                        />
                        <span 
                          style={{ height: `${Math.max(4, audioLevel * 12)}px` }}
                          className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                        />
                        <span className="text-[9px] font-mono text-emerald-300 font-bold ml-0.5">Voz</span>
                      </div>
                    )}
                  </div>

                  {/* Speaker Details & Institutional Badges */}
                  <div className="text-center">
                    <h3 className="text-lg font-black text-white tracking-tight flex items-center justify-center gap-1.5">
                      <span>{featuredDelegate?.name}</span>
                      {featuredDelegate?.role === 'DELEGATE' && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                          Voz y Voto
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-purple-200 font-semibold mt-0.5">
                      {featuredDelegate?.organization} · Región de {featuredDelegate?.region}
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                      Criterio Paritario: {featuredDelegate?.gender}
                    </p>
                  </div>

                </div>
              </div>
            )}
          </div>
        )}

        {/* Floating Reactions Rendering */}
        <div className="absolute inset-0 pointer-events-none z-25 overflow-hidden">
          {reactions.map((r) => (
            <div
              key={r.id}
              style={{ left: `${r.x}%` }}
              className="absolute bottom-16 animate-bounce text-2xl drop-shadow-lg transition-all duration-1000 opacity-90 flex flex-col items-center"
            >
              <span>{r.emoji}</span>
              <span className="text-[9px] text-white/80 font-mono font-bold bg-black/50 px-1 rounded backdrop-blur-xs">
                {r.senderName.split(' ')[0]}
              </span>
            </div>
          ))}
        </div>

      </div>

      {/* 3. BOTTOM OVERLAY BAR: Audio Meter, Reactions, Microphone, Speaker Identity & Volume */}
      <div className="relative z-30 bg-gradient-to-t from-black/95 via-black/75 to-transparent p-3 flex items-center justify-between gap-3 pointer-events-auto">
        
        {/* Left: Speaker Information Banner */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
          <div className="text-xs text-slate-200 font-bold truncate">
            {activeSpeaker 
              ? `En el uso de la palabra: ${activeSpeaker.delegateName} (${activeSpeaker.region})` 
              : 'Plenario Nacional FE-FA · Sesión Deliberativa Oficial'}
          </div>
        </div>

        {/* Center: Audio VU Meter Visualizer */}
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 bg-black/60 rounded-xl border border-white/10 backdrop-blur-xs">
          <span className="text-[9px] text-slate-400 font-mono uppercase">Modulación</span>
          <div className="flex items-end gap-0.5 h-3.5 w-16 bg-slate-900 rounded p-0.5 border border-slate-800">
            {[1, 2, 3, 4, 5, 6, 7].map((bar) => {
              const threshold = bar / 7;
              const isActive = audioLevel >= threshold;
              return (
                <div
                  key={bar}
                  style={{ height: `${(bar / 7) * 100}%` }}
                  className={`w-1 rounded-xs transition-colors duration-75 ${
                    isActive 
                      ? bar >= 6 ? 'bg-rose-500' : bar >= 4 ? 'bg-amber-400' : 'bg-emerald-400' 
                      : 'bg-slate-700'
                  }`}
                />
              );
            })}
          </div>
        </div>

        {/* Right: Interactive Conference Controls */}
        <div className="flex items-center gap-2 shrink-0">
          
          {/* Reaction Picker Button */}
          <div className="relative">
            <button
              onClick={() => setShowReactionPicker(!showReactionPicker)}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs transition-all flex items-center gap-1 cursor-pointer"
              title="Enviar reacción a la sala"
            >
              <Smile className="w-4 h-4 text-amber-300" />
            </button>

            {/* Reaction Popover */}
            {showReactionPicker && (
              <div className="absolute bottom-10 right-0 bg-slate-900/95 border border-white/20 rounded-2xl p-2 shadow-2xl flex items-center gap-1.5 z-40 backdrop-blur-md animate-in fade-in zoom-in-95 duration-100">
                {['👏', '✊', '✋', '👍', '💡', '🇨🇱'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => sendReaction(emoji)}
                    className="p-1.5 text-base hover:scale-125 transition-transform cursor-pointer"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Volume Control / Mute Output */}
          <button
            onClick={() => setIsDeafened(!isDeafened)}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white text-xs transition-colors cursor-pointer"
            title={isDeafened ? 'Activar audio de sala' : 'Silenciar audio de sala'}
          >
            {isDeafened ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* User Mic Toggle */}
          <button
            onClick={() => setIsMicOn(!isMicOn)}
            disabled={forceMuted && !isDireccionNacional}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm ${
              isMicOn 
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white ring-2 ring-emerald-400/30' 
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white'
            } ${forceMuted && !isDireccionNacional ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={forceMuted && !isDireccionNacional ? 'Micrófonos silenciados por la Mesa Directiva' : isMicOn ? 'Silenciar micrófono' : 'Activar micrófono'}
          >
            {isMicOn ? <Mic className="w-4 h-4 text-white" /> : <MicOff className="w-4 h-4 text-rose-400" />}
            <span className="hidden sm:inline">{isMicOn ? 'Mic Activo' : 'Silenciado'}</span>
          </button>

          {/* Mesa Directiva / Secretaria Tecnica Global Moderation Button */}
          {(isDireccionNacional || isSecretariaTecnica) && (
            <button
              onClick={() => setForceMuted(!forceMuted)}
              className={`p-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                forceMuted 
                  ? 'bg-rose-600 text-white shadow-xs' 
                  : 'bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white'
              }`}
              title={forceMuted ? 'Desactivar Silencio Forzado de Sala' : 'Activar Silencio Forzado de Sala (Silenciar a todos)'}
            >
              <Shield className="w-4 h-4 text-rose-400" />
            </button>
          )}

          {/* Conference Settings Toggle */}
          <button
            onClick={() => setShowSettingsModal(true)}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white text-xs transition-colors cursor-pointer"
            title="Ajustes de videoconferencia y fondos virtuales"
          >
            <Settings className="w-4 h-4" />
          </button>

        </div>

      </div>

      {/* 4. MODAL: Video & Audio Settings */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-purple-400" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Configuración de Videoconferencia
                </h3>
              </div>
              <button 
                onClick={() => setShowSettingsModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              
              {/* Camera selection */}
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Dispositivo de Cámara
                </label>
                <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-between">
                  <span className="font-mono text-slate-200">
                    {useRealWebcam ? 'Cámara Web Integrada (HD 1080p)' : 'Avatar Criptográfico Acreditado (FE-FA)'}
                  </span>
                  <button
                    onClick={() => setUseRealWebcam(!useRealWebcam)}
                    className="px-2.5 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold text-[11px]"
                  >
                    {useRealWebcam ? 'Desactivar' : 'Activar WebCam'}
                  </button>
                </div>
              </div>

              {/* Virtual Background */}
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Efecto de Fondo Virtual
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setVirtualBg('NONE')}
                    className={`p-2 rounded-xl border text-center font-bold ${
                      virtualBg === 'NONE' ? 'bg-[#4A154B] text-white border-purple-400' : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    Estándar
                  </button>
                  <button
                    onClick={() => setVirtualBg('BLUR')}
                    className={`p-2 rounded-xl border text-center font-bold ${
                      virtualBg === 'BLUR' ? 'bg-[#4A154B] text-white border-purple-400' : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    Desenfocar
                  </button>
                  <button
                    onClick={() => setVirtualBg('CONGRESO')}
                    className={`p-2 rounded-xl border text-center font-bold ${
                      virtualBg === 'CONGRESO' ? 'bg-[#4A154B] text-white border-purple-400' : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    Institucional
                  </button>
                </div>
              </div>

              {/* Bandwidth Priority */}
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Calidad y Ancho de Banda
                </label>
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="bandwidth"
                      checked={!lowBandwidthMode}
                      onChange={() => setLowBandwidthMode(false)}
                      className="text-purple-600 focus:ring-purple-500"
                    />
                    <div>
                      <div className="font-bold text-white">Alta Definición (HD 1080p)</div>
                      <div className="text-[10px] text-slate-400">Transmisión completa de video WebRTC y audio espacial</div>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer pt-2 border-t border-slate-700/60">
                    <input
                      type="radio"
                      name="bandwidth"
                      checked={lowBandwidthMode}
                      onChange={() => setLowBandwidthMode(true)}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <div>
                      <div className="font-bold text-amber-300">Bajo Consumo / Modo IMG (32 kbps)</div>
                      <div className="text-[10px] text-slate-400">Prioriza el audio y la votación; ideal para conexiones regionales inestables</div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Audio Volume */}
              <div>
                <div className="flex items-center justify-between font-bold text-slate-300 mb-1">
                  <span>Volumen de Sala</span>
                  <span className="font-mono text-purple-300">{volume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-full accent-[#4A154B] cursor-pointer"
                />
              </div>

            </div>

            <div className="mt-5 pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowSettingsModal(false)}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold text-xs"
              >
                Cerrar y Aplicar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
