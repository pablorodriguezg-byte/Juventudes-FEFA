import React from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  Clock, 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';

export const TiempoPalabraBox: React.FC = () => {
  const { 
    timerSeconds, 
    timerTotal, 
    isTimerRunning, 
    startTimer, 
    pauseTimer, 
    resetTimer, 
    addThirtySeconds, 
    isDireccionNacional,
    activeSpeaker,
    currentUser,
    finishSpeaking
  } = usePlenario();

  const isCriticalTime = timerSeconds <= 20 && timerSeconds > 0;
  const isTimeOut = timerSeconds === 0;
  const isModerator = isDireccionNacional;
  const isCurrentSpeaker = activeSpeaker?.delegateId === currentUser?.id;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className={`rounded-2xl border px-3.5 py-2 shadow-sm transition-all flex flex-col justify-between shrink-0 ${
      isTimeOut
        ? 'bg-rose-50 border-rose-400 text-rose-950'
        : isCriticalTime
          ? 'bg-rose-50/90 border-rose-300 text-rose-950 animate-pulse'
          : 'bg-white border-slate-200 text-slate-900'
    }`}>
      
      {/* Top compact row: Label, Active Speaker & Big Digital Time */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <div className="w-5 h-5 rounded-lg bg-[#4A154B] text-white flex items-center justify-center shrink-0 shadow-2xs">
            <Clock className="w-3 h-3" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[10px] font-black text-slate-900 uppercase tracking-wider truncate">
              TIEMPO PALABRA
            </span>
            <span className="text-[9px] text-slate-500 font-medium truncate">
              {activeSpeaker ? activeSpeaker.delegateName : 'Mesa en conducción'}
            </span>
          </div>
        </div>

        {/* Center: Digital Timer Display */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className={`text-xl font-black font-mono tracking-tight tabular-nums ${
            isTimeOut ? 'text-rose-600' : isCriticalTime ? 'text-rose-600' : 'text-slate-900'
          }`}>
            {formatTime(timerSeconds)}
          </div>
          {isCriticalTime && (
            <span className="text-[9px] font-bold text-rose-700 bg-rose-100 px-1 py-0.2 rounded">
              -20s
            </span>
          )}
        </div>

        {/* Controls: Compact buttons */}
        <div className="flex items-center gap-1 shrink-0">
          {isModerator ? (
            <>
              <button
                onClick={isTimerRunning ? pauseTimer : startTimer}
                className={`p-1.5 rounded-lg text-[10px] font-bold flex items-center justify-center transition-all cursor-pointer ${
                  isTimerRunning 
                    ? 'bg-amber-500 hover:bg-amber-600 text-white' 
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
                title={isTimerRunning ? 'Pausar' : 'Iniciar'}
              >
                {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              </button>

              <button
                onClick={addThirtySeconds}
                className="px-1.5 py-1 bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 rounded-lg text-[10px] font-bold flex items-center gap-0.5 cursor-pointer"
                title="Conceder prórroga de +30 segundos"
              >
                <Plus className="w-2.5 h-2.5" />
                <span>30s</span>
              </button>

              <button
                onClick={() => resetTimer(120)}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] cursor-pointer"
                title="Reiniciar a 2:00 min"
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            </>
          ) : isCurrentSpeaker ? (
            <button
              onClick={finishSpeaking}
              className="py-1 px-2.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Concluir</span>
            </button>
          ) : (
            <span className="text-[9px] text-slate-400 font-mono">
              2 min máx
            </span>
          )}
        </div>
      </div>

      {/* Thin Progress Bar below */}
      <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden mt-1.5">
        <div 
          className={`h-full transition-all duration-1000 ${
            isTimeOut 
              ? 'bg-rose-600 w-full' 
              : isCriticalTime 
                ? 'bg-rose-500' 
                : 'bg-gradient-to-r from-[#4A154B] to-[#D32F2F]'
          }`}
          style={{ width: `${Math.min(100, (timerSeconds / timerTotal) * 100)}%` }}
        />
      </div>

    </div>
  );
};
