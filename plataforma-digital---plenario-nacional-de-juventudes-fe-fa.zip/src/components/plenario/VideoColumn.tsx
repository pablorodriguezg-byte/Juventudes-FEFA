import React, { useState, useRef, useEffect } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Hand, 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  UserCheck, 
  VolumeX, 
  AlertTriangle,
  Radio,
  Camera,
  CheckCircle2
} from 'lucide-react';

export const VideoColumn: React.FC = () => {
  const { 
    currentUser, 
    activeSpeaker, 
    speakerQueue, 
    timerSeconds, 
    timerTotal,
    isTimerRunning,
    lowBandwidthMode,
    forceMuted,
    setForceMuted,
    requestWord,
    withdrawWord,
    giveWordToSpeaker,
    finishSpeaking,
    startTimer,
    pauseTimer,
    resetTimer,
    addThirtySeconds,
    isDireccionNacional,
    isDelegate,
    takeFloorAsPresidency
  } = usePlenario();

  const [isMicOn, setIsMicOn] = useState(false);
  const [isCamOn, setIsCamOn] = useState(false);
  const [useRealWebcam, setUseRealWebcam] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Manage real camera access if user enables webcam
  useEffect(() => {
    if (useRealWebcam && isCamOn) {
      navigator.mediaDevices?.getUserMedia({ video: true, audio: true })
        .then(stream => {
          mediaStreamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch(err => {
          console.warn('Webcam permission not granted or available:', err);
          setUseRealWebcam(false);
        });
    } else {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
    }
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [useRealWebcam, isCamOn]);

  const hasRequestedWord = speakerQueue.some(i => i.delegateId === currentUser?.id && i.status !== 'COMPLETED');
  const isCurrentSpeaker = activeSpeaker?.delegateId === currentUser?.id;
  const isModerator = isDireccionNacional;

  // Format time mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const isCriticalTime = timerSeconds <= 20 && timerSeconds > 0;
  const isTimeOut = timerSeconds === 0;

  return (
    <div className="flex flex-col gap-3 w-full min-w-0">
      
      {/* 1. Main WebRTC Video Display */}
      <div className="relative rounded-2xl bg-slate-900 border border-slate-300 overflow-hidden shadow-sm aspect-video max-h-52 w-full flex flex-col justify-between shrink-0">
        
        {/* Top Video Scrim & Active Status */}
        <div className="absolute top-0 inset-x-0 p-3 bg-gradient-to-b from-black/80 via-black/30 to-transparent z-10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-bold tracking-wide uppercase shadow">
              <Radio className="w-3 h-3 animate-pulse" />
              <span>En Vivo · WebRTC</span>
            </span>
            {lowBandwidthMode && (
              <span className="px-2 py-0.5 rounded-full bg-amber-500 text-black text-[11px] font-bold">
                Audio Prioritario
              </span>
            )}
          </div>

          {/* Toggle real device camera preview */}
          <button
            onClick={() => {
              setUseRealWebcam(!useRealWebcam);
              setIsCamOn(!useRealWebcam);
            }}
            className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
              useRealWebcam ? 'bg-[#6A1B9A] text-white' : 'bg-black/60 text-slate-200 hover:text-white'
            }`}
            title="Conectar cámara web real para transmitir"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{useRealWebcam ? 'Cámara Local' : 'Emisión Oficial'}</span>
          </button>
        </div>

        {/* Video stream center */}
        <div className="relative flex-1 flex items-center justify-center w-full h-full bg-[#0F172A]">
          {lowBandwidthMode ? (
            /* Reduced Bandwidth Audio Avatar */
            <div className="flex flex-col items-center justify-center p-6 text-center">
              <div className="w-18 h-18 rounded-full bg-gradient-to-tr from-[#4A154B] to-[#D32F2F] flex items-center justify-center text-2xl font-bold text-white shadow mb-3">
                {activeSpeaker ? activeSpeaker.delegateName.charAt(0) : 'P'}
              </div>
              <div className="text-white font-bold text-sm">
                {activeSpeaker ? activeSpeaker.delegateName : 'Plenario en receso de oratoria'}
              </div>
              <div className="text-xs text-amber-300 mt-1">
                Modo Ancho de Banda Reducido activo: optimización de datos en red móvil.
              </div>
            </div>
          ) : useRealWebcam ? (
            /* Local User Webcam Feed */
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted 
              className="w-full h-full object-cover transform -scale-x-100"
            />
          ) : activeSpeaker ? (
            /* HD Speaker Stream Simulation with Rich Background */
            <div className="relative w-full h-full flex items-center justify-center bg-radial from-[#241235] to-[#0c0d16] overflow-hidden">
              <div className="relative z-10 flex flex-col items-center p-4">
                <div className="relative mb-2.5">
                  <div className={`w-24 h-24 rounded-2xl overflow-hidden border-2 shadow-2xl ${
                    isCriticalTime ? 'border-rose-500 ring-4 ring-rose-500/40 animate-pulse' : 'border-purple-400'
                  }`}>
                    <img 
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80" 
                      alt={activeSpeaker.delegateName}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  {/* Speaking indicator soundwave bar */}
                  {isTimerRunning && (
                    <div className="absolute -bottom-2 inset-x-0 mx-auto w-16 bg-slate-900 border border-purple-400 rounded-full py-0.5 px-2 flex items-center justify-center gap-1 shadow">
                      <span className="w-1 h-3 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-1 h-4 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-1 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  )}
                </div>

                <div className="text-center">
                  <h3 className="text-sm font-bold text-white tracking-tight">
                    {activeSpeaker.delegateName}
                  </h3>
                  <p className="text-[11px] text-purple-200 font-semibold">
                    Región de {activeSpeaker.region} · {activeSpeaker.gender}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* Waiting for speaker */
            <div className="flex flex-col items-center justify-center p-6 text-center text-slate-300">
              <UserCheck className="w-10 h-10 text-slate-400 mb-2" />
              <p className="text-sm font-bold text-slate-200">Sala en deliberación general</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                La Mesa Directiva concederá la palabra alternando paridad de género y bancadas regionales.
              </p>
            </div>
          )}
        </div>

        {/* Bottom Video Bar with Speaker Overlay & Media Toggles */}
        <div className="relative z-10 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-200 font-semibold">
              {activeSpeaker ? `En uso de la palabra: ${activeSpeaker.delegateName.split(' ')[0]}` : 'Plenario FE-FA'}
            </span>
          </div>

          {/* Quick mic/cam toggles for current user */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMicOn(!isMicOn)}
              disabled={forceMuted && !isModerator}
              className={`p-2 rounded-xl text-xs transition-colors flex items-center gap-1 cursor-pointer ${
                isMicOn 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              } ${forceMuted ? 'opacity-50 cursor-not-allowed' : ''}`}
              title={forceMuted ? 'Micrófonos silenciados por la Mesa' : isMicOn ? 'Silenciar micrófono' : 'Activar micrófono'}
            >
              {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setIsCamOn(!isCamOn)}
              className={`p-2 rounded-xl text-xs transition-colors flex items-center gap-1 cursor-pointer ${
                isCamOn 
                  ? 'bg-[#4A154B] text-white' 
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
              title={isCamOn ? 'Desactivar cámara' : 'Activar cámara'}
            >
              {isCamOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>
          </div>
        </div>

      </div>

      {/* 2. Official Digital Countdown Timer */}
      <div className={`rounded-2xl p-4 border transition-all shadow-sm ${
        isTimeOut
          ? 'bg-rose-50 border-rose-400 text-rose-900'
          : isCriticalTime 
            ? 'bg-rose-50 border-rose-300 text-rose-900 animate-pulse' 
            : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-900">
              Cronómetro de Oratoria
            </span>
            {isCriticalTime && (
              <span className="flex items-center gap-1 text-[11px] font-bold text-rose-800 bg-rose-100 px-2 py-0.5 rounded border border-rose-300">
                <AlertTriangle className="w-3 h-3" />
                Tramo Crítico
              </span>
            )}
            {isTimeOut && (
              <span className="text-[11px] font-bold text-rose-800 bg-rose-200 px-2 py-0.5 rounded border border-rose-300">
                Tiempo Agotado
              </span>
            )}
          </div>

          <div className="text-[11px] text-slate-500 font-mono font-medium">
            Límite: {formatTime(timerTotal)}
          </div>
        </div>

        {/* Big Numeric Clock Display */}
        <div className="flex items-baseline justify-between py-1">
          <div className={`text-4xl font-black tracking-tight font-mono tabular-nums ${
            isTimeOut ? 'text-rose-600' : isCriticalTime ? 'text-rose-600' : 'text-slate-900'
          }`}>
            {formatTime(timerSeconds)}
          </div>

          {/* Directiva & Orator Controls */}
          {isModerator ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={isTimerRunning ? pauseTimer : startTimer}
                className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer ${
                  isTimerRunning ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
                title={isTimerRunning ? 'Pausar cronómetro' : 'Reanudar'}
              >
                {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>

              <button
                onClick={addThirtySeconds}
                className="px-2.5 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 text-xs font-bold flex items-center gap-1 cursor-pointer"
                title="Conceder +30 segundos de prórroga"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+30s</span>
              </button>

              <button
                onClick={() => resetTimer(120)}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs cursor-pointer border border-slate-200"
                title="Reiniciar a 2:00 min"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          ) : isCurrentSpeaker ? (
            <button
              onClick={finishSpeaking}
              className="px-3.5 py-2 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Concluir Palabra</span>
            </button>
          ) : null}
        </div>

        {/* Progress Bar with Gradient and Critical Stage */}
        <div className="w-full h-2 bg-slate-100 border border-slate-200 rounded-full mt-3 overflow-hidden">
          <div 
            className={`h-full transition-all duration-1000 ${
              isTimeOut 
                ? 'bg-rose-600 w-full' 
                : isCriticalTime 
                  ? 'bg-rose-500' 
                  : 'bg-gradient-to-r from-[#4A154B] to-[#D32F2F]'
            }`}
            style={{ width: `${Math.min(100, (timerSeconds / timerTotal) * 100)}%` }}
          />
        </div>
      </div>

      {/* 3. Speaker Turn Queue with Gender Parity & Regional Alternation */}
      <div className="rounded-2xl bg-white border border-slate-200 p-3.5 shadow-sm flex flex-col">
        <div className="flex items-center justify-between mb-2">
          <div className="flex flex-col">
            <span className="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>Pedido de Palabra</span>
              <span className="text-[10px] text-purple-900 font-normal">
                (Paridad y Descentralización)
              </span>
            </span>
          </div>

          {/* Hand Raise / Speaking Control according to Role */}
          {currentUser && (
            <div>
              {isDireccionNacional ? (
                <div className="flex items-center gap-1.5">
                  {isCurrentSpeaker ? (
                    <button
                      onClick={finishSpeaking}
                      className="px-3 py-1.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Concluir Intervención</span>
                    </button>
                  ) : (
                    <button
                      onClick={takeFloorAsPresidency}
                      className="px-3 py-1.5 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow transition-all cursor-pointer"
                      title="Hacer uso de la palabra como Dirección Nacional para presidir y orientar el debate"
                    >
                      <Mic className="w-3.5 h-3.5 text-purple-200" />
                      <span>Intervenir desde Mesa</span>
                    </button>
                  )}
                </div>
              ) : hasRequestedWord ? (
                <button
                  onClick={withdrawWord}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors border border-slate-300 cursor-pointer"
                >
                  <Hand className="w-3.5 h-3.5 text-amber-600" />
                  <span>Bajar Mano</span>
                </button>
              ) : (
                <button
                  onClick={requestWord}
                  disabled={isCurrentSpeaker}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow transition-all cursor-pointer disabled:opacity-50"
                >
                  <Hand className="w-3.5 h-3.5" />
                  <span>Pedir Palabra</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Explanation text on algorithmic ordering */}
        <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
          El orden de intervenciones prioriza alternancia de género y representación equitativa de regiones extremas.
        </p>

        {/* Queue Items List */}
        <div className="space-y-2 flex-1 overflow-y-auto max-h-56 pr-1">
          {speakerQueue.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-xs">
              No hay solicitudes pendientes en la cola.
            </div>
          ) : (
            speakerQueue.map((item, idx) => (
              <div 
                key={item.id}
                className={`p-2.5 rounded-xl border text-xs flex items-center justify-between transition-all ${
                  item.status === 'SPEAKING'
                    ? 'bg-purple-50 border-purple-300 text-purple-950 ring-1 ring-purple-300 font-semibold'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="w-5 h-5 rounded-full bg-slate-200 text-[10px] font-mono font-bold flex items-center justify-center text-slate-700 shrink-0">
                    {idx + 1}
                  </span>

                  <div className="flex flex-col min-w-0">
                    <span className="font-bold text-slate-900 truncate">
                      {item.delegateName}
                    </span>
                    <span className="text-[10px] text-slate-500 flex items-center gap-1.5">
                      <span className="text-purple-900 font-semibold">{item.region}</span>
                      <span>·</span>
                      <span>{item.gender}</span>
                      <span>·</span>
                      <span className="font-mono">Prioridad {item.priorityScore} pts</span>
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {item.status === 'SPEAKING' ? (
                    <span className="text-[11px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded border border-rose-300">
                      En Oratoria
                    </span>
                  ) : isModerator ? (
                    <button
                      onClick={() => giveWordToSpeaker(item.id)}
                      className="px-2.5 py-1 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                    >
                      Ceder Palabra
                    </button>
                  ) : null}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Moderator Bulk Action: Force Mute All */}
        {isModerator && (
          <div className="pt-3 border-t border-slate-200 mt-2 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 font-medium">Control de Sala:</span>
            <button
              onClick={() => setForceMuted(!forceMuted)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                forceMuted 
                  ? 'bg-rose-100 text-rose-800 border border-rose-300' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
              }`}
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span>{forceMuted ? 'Micrófonos Silenciados' : 'Silencio Forzado General'}</span>
            </button>
          </div>
        )}

      </div>

    </div>
  );
};
