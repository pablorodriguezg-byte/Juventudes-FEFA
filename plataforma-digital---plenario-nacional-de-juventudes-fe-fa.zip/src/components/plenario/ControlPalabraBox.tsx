import React, { useState } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  Hand, 
  Mic, 
  CheckCircle2, 
  VolumeX, 
  Users, 
  Sparkles,
  MessageSquare,
  Repeat,
  X,
  Send,
  ShieldAlert
} from 'lucide-react';
import { OrderMotionCategory } from '../../types/plenario';

export const ControlPalabraBox: React.FC = () => {
  const { 
    currentUser, 
    speakerQueue, 
    activeSpeaker, 
    requestWord, 
    withdrawWord, 
    giveWordToSpeaker, 
    finishSpeaking, 
    takeFloorAsPresidency, 
    isDireccionNacional,
    forceMuted,
    setForceMuted,
    sendOrderMotion,
    orderMotions,
    resolveOrderMotion,
    addAuditLog
  } = usePlenario();

  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showReplicaModal, setShowReplicaModal] = useState(false);
  const [orderCategory, setOrderCategory] = useState<OrderMotionCategory>('MOCION_ORDEN');
  const [orderMessage, setOrderMessage] = useState('');
  const [replicaTarget, setReplicaTarget] = useState('');
  const [replicaJustification, setReplicaJustification] = useState('');

  const hasRequestedWord = speakerQueue.some(i => i.delegateId === currentUser?.id && i.status !== 'COMPLETED');
  const isCurrentSpeaker = activeSpeaker?.delegateId === currentUser?.id;
  const isModerator = isDireccionNacional;

  const handleSendOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderMessage.trim()) return;
    sendOrderMotion(orderCategory, orderMessage.trim());
    setOrderMessage('');
    setShowOrderModal(false);
  };

  const handleSendReplica = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replicaTarget.trim() || !replicaJustification.trim()) return;
    sendOrderMotion('PUNTO_INFORMACION', `[SOLICITUD DE RÉPLICA] Alusión directa por ${replicaTarget.trim()}: "${replicaJustification.trim()}"`);
    addAuditLog('SOLICITUD_REPLICA', `${currentUser?.name || 'Delegado'} solicitó derecho a réplica por alusión directa.`);
    setReplicaTarget('');
    setReplicaJustification('');
    setShowReplicaModal(false);
  };

  const pendingOrdersCount = orderMotions.filter(o => o.status === 'PENDIENTE').length;

  return (
    <>
      <div className="flex flex-col h-full w-full min-w-0 bg-white border border-slate-200 rounded-2xl shadow-sm p-3.5 overflow-hidden">
        
        {/* Header: CONTROL DE PALABRA */}
        <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-1.5 min-w-0">
            <Hand className="w-4 h-4 text-[#4A154B] shrink-0" />
            <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider truncate">
              CONTROL DE PALABRA
            </h3>
          </div>

          {/* Hand Raise / Speaker Action Button */}
          <div className="shrink-0 flex items-center gap-1.5">
            {currentUser && (
              isDireccionNacional ? (
                isCurrentSpeaker ? (
                  <button
                    onClick={finishSpeaking}
                    className="px-2.5 py-1 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-[10px] font-bold rounded-lg flex items-center gap-1 shadow-xs cursor-pointer"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-300" />
                    <span>Concluir</span>
                  </button>
                ) : (
                  <button
                    onClick={takeFloorAsPresidency}
                    className="px-2.5 py-1 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white text-[10px] font-bold rounded-lg flex items-center gap-1 shadow-xs cursor-pointer hover:brightness-110"
                    title="Intervenir desde Mesa Directiva"
                  >
                    <Mic className="w-3 h-3" />
                    <span>Mesa</span>
                  </button>
                )
              ) : hasRequestedWord ? (
                <button
                  onClick={withdrawWord}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-[10px] font-bold rounded-lg flex items-center gap-1 border border-slate-300 cursor-pointer"
                >
                  <Hand className="w-3 h-3 text-amber-600" />
                  <span>Bajar</span>
                </button>
              ) : (
                <button
                  onClick={requestWord}
                  disabled={isCurrentSpeaker}
                  className="px-2.5 py-1 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white text-[10px] font-bold rounded-lg flex items-center gap-1 shadow-xs cursor-pointer disabled:opacity-50 hover:brightness-110"
                >
                  <Hand className="w-3 h-3" />
                  <span>Pedir</span>
                </button>
              )
            )}
          </div>
        </div>

        {/* Speaker Queue List with Parity Ranking */}
        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 text-xs">
          {speakerQueue.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-xs">
              Sin solicitudes de palabra pendientes.
            </div>
          ) : (
            speakerQueue.map((item, idx) => (
              <div 
                key={item.id}
                className={`p-2 rounded-xl border text-[11px] flex items-center justify-between gap-2 transition-all ${
                  item.status === 'SPEAKING'
                    ? 'bg-purple-50 border-purple-300 text-purple-950 font-semibold'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="w-4 h-4 rounded-full bg-slate-200 text-[9px] font-mono font-bold flex items-center justify-center text-slate-700 shrink-0">
                    {idx + 1}
                  </span>

                  <div className="flex flex-col min-w-0">
                    <span className="font-bold text-slate-900 truncate max-w-[130px]">
                      {item.delegateName}
                    </span>
                    <span className="text-[9px] text-slate-500 truncate">
                      {item.region} · {item.gender}
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  {item.status === 'SPEAKING' ? (
                    <span className="text-[9px] font-bold text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded border border-rose-200">
                      En uso
                    </span>
                  ) : isModerator ? (
                    <button
                      onClick={() => giveWordToSpeaker(item.id)}
                      className="px-2 py-0.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded text-[10px] font-bold cursor-pointer"
                    >
                      Ceder
                    </button>
                  ) : null}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Bottom Actions Bar: Mociones de Orden [MÓ], [Réplica] & Silencio forzado */}
        <div className="pt-2 border-t border-slate-100 mt-1 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1.5">
            {/* Quick Action: MÓ */}
            <button
              onClick={() => setShowOrderModal(true)}
              className="px-2 py-0.5 rounded-lg bg-purple-50 hover:bg-[#4A154B] text-[#4A154B] hover:text-white border border-purple-200 text-[10px] font-extrabold flex items-center gap-1 transition-all cursor-pointer relative"
              title="Moción de Orden / Punto de Información"
            >
              <span>MÓ</span>
              {pendingOrdersCount > 0 && (
                <span className="w-3.5 h-3.5 rounded-full bg-rose-600 text-white text-[8px] font-bold flex items-center justify-center">
                  {pendingOrdersCount}
                </span>
              )}
            </button>

            {/* Quick Action: Réplica */}
            <button
              onClick={() => setShowReplicaModal(true)}
              className="px-2 py-0.5 rounded-lg bg-slate-50 hover:bg-[#4A154B] text-slate-700 hover:text-white border border-slate-300 text-[10px] font-bold transition-all cursor-pointer"
              title="Solicitar Derecho a Réplica por alusión directa"
            >
              <span>Réplica</span>
            </button>
          </div>

          {/* Moderator Silencio Forzado */}
          {isModerator ? (
            <button
              onClick={() => setForceMuted(!forceMuted)}
              className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                forceMuted 
                  ? 'bg-rose-100 text-rose-800 border border-rose-300' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <VolumeX className="w-3 h-3" />
              <span>{forceMuted ? 'Silenciado' : 'Silencio'}</span>
            </button>
          ) : (
            <span className="text-[9px] text-slate-400 font-mono">
              Paridad par/impar
            </span>
          )}
        </div>

      </div>

      {/* Modal: Moción de Orden [ MÓ ] */}
      {showOrderModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg p-5 shadow-2xl text-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-200 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#4A154B] text-white flex items-center justify-center text-xs font-black">
                  MÓ
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    Mociones de Orden & Mesa Técnica
                  </h3>
                  <span className="text-[10px] text-purple-900 font-medium">
                    Canal reglamentario con la Mesa Directiva
                  </span>
                </div>
              </div>
              <button onClick={() => setShowOrderModal(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Existing Messages Feed */}
            <div className="max-h-48 overflow-y-auto space-y-1.5 mb-3 p-2 bg-slate-50 rounded-xl border border-slate-200">
              {orderMotions.length === 0 ? (
                <div className="text-center py-4 text-slate-400 text-xs">Sin mociones activas.</div>
              ) : (
                orderMotions.slice(0, 5).map(om => (
                  <div key={om.id} className="p-2 rounded-lg bg-white border border-slate-200 text-xs">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-slate-800 text-[11px]">{om.delegateName}</span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                        om.status === 'ATENDIDA' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {om.status}
                      </span>
                    </div>
                    <p className="text-slate-600 text-[11px]">{om.message}</p>
                    {isDireccionNacional && om.status === 'PENDIENTE' && (
                      <div className="flex items-center justify-end gap-1 mt-1">
                        <button
                          onClick={() => resolveOrderMotion(om.id, 'ATENDIDA')}
                          className="px-2 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-bold"
                        >
                          Atender
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Form */}
            <form onSubmit={handleSendOrder} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Tipo de Moción</label>
                <select
                  value={orderCategory}
                  onChange={(e) => setOrderCategory(e.target.value as OrderMotionCategory)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B]"
                >
                  <option value="MOCION_ORDEN">Moción de Orden (Cumplimiento de Reglamento)</option>
                  <option value="PUNTO_INFORMACION">Punto de Información (Hecho o Dato Crucial)</option>
                  <option value="CUESTION_PREVIA">Cuestión Previa (Inadmisibilidad Formal)</option>
                  <option value="MOCION_CENSURA">Moción de Censura a la Conducción</option>
                  <option value="MESA_AYUDA">Mesa de Ayuda y Soporte Técnico</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Fundamentación o Mensaje</label>
                <textarea
                  rows={3}
                  required
                  value={orderMessage}
                  onChange={(e) => setOrderMessage(e.target.value)}
                  placeholder="Explique concisamente la moción de orden para la Mesa Directiva..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cerrar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-xs font-bold rounded-xl shadow cursor-pointer"
                >
                  Enviar a la Mesa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Solicitud de Réplica [ REPLIC ] */}
      {showReplicaModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-5 shadow-2xl text-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-200 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-white flex items-center justify-center text-[10px] font-black">
                  REPLIC
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    Solicitud de Derecho a Réplica
                  </h3>
                  <span className="text-[10px] text-purple-900 font-medium">
                    1:00 minuto reglamentario por alusión directa
                  </span>
                </div>
              </div>
              <button onClick={() => setShowReplicaModal(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendReplica} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Orador o Delegación que realizó la alusión directa
                </label>
                <input
                  type="text"
                  required
                  value={replicaTarget}
                  onChange={(e) => setReplicaTarget(e.target.value)}
                  placeholder="Ej: Sofía Carvajal (Antofagasta) o Mesa Directiva"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Motivo de la Réplica (Aclaración de hecho)
                </label>
                <textarea
                  rows={3}
                  required
                  value={replicaJustification}
                  onChange={(e) => setReplicaJustification(e.target.value)}
                  placeholder="Detalle la alusión o juicio emitido para que la Mesa conceda la réplica..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B]"
                />
              </div>

              <div className="p-2.5 bg-purple-50 rounded-xl border border-purple-200 text-[10px] text-purple-950 font-medium">
                Conforme al reglamento, la concesión de réplicas es evaluada de inmediato por la Mesa Directiva.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowReplicaModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-xs font-bold rounded-xl shadow cursor-pointer"
                >
                  Solicitar Réplica
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
