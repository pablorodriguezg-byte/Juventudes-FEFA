import React, { useState } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { 
  FileText, 
  Check, 
  AlertCircle, 
  PlusCircle, 
  ArrowUpRight, 
  Eye, 
  Edit3, 
  BookmarkCheck,
  Clock,
  Send
} from 'lucide-react';
import { SynthesisChapter, ChangeProposal } from '../../types/plenario';

export const SynthesisColumn: React.FC = () => {
  const { 
    currentUser, 
    synthesisChapters, 
    updateChapterContent, 
    addChangeProposal, 
    elevateProposalToMotion,
    isDireccionNacional,
    isDelegate
  } = usePlenario();

  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [isReadingMode, setIsReadingMode] = useState(false);
  const [showProposalModal, setShowProposalModal] = useState(false);
  const [proposalType, setProposalType] = useState<'CONSENSO' | 'DISENSO'>('DISENSO');
  const [proposalText, setProposalText] = useState('');
  const [proposalJustification, setProposalJustification] = useState('');

  const currentChapter = synthesisChapters[activeChapterIndex] || synthesisChapters[0];
  const isSecretary = isDireccionNacional;

  const handleCreateProposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!proposalText.trim() || !proposalJustification.trim()) return;
    addChangeProposal(currentChapter.id, proposalText.trim(), proposalJustification.trim(), proposalType);
    setProposalText('');
    setProposalJustification('');
    setShowProposalModal(false);
  };

  return (
    <div className={`rounded-2xl border flex flex-col h-full w-full min-w-0 transition-all shadow-sm ${
      isReadingMode 
        ? 'bg-amber-50/20 text-slate-900 border-amber-200' 
        : 'bg-white text-slate-800 border-slate-200'
    }`}>
      
      {/* Top Header & Chapter Selector */}
      <div className="p-4 border-b border-slate-200 bg-slate-50/70 rounded-t-2xl flex flex-col gap-3 shrink-0">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#4A154B] text-white shrink-0">
              <FileText className="w-4 h-4 text-purple-200" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-slate-900 tracking-tight">
                Síntesis Nacional Única (En Vivo)
              </h2>
              <span className="text-[11px] font-mono text-purple-900 font-medium">
                {currentChapter.lastModifiedBy} · {new Date(currentChapter.lastModifiedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Toggle Reading vs Edit Mode */}
            <button
              onClick={() => setIsReadingMode(!isReadingMode)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors border ${
                isReadingMode 
                  ? 'bg-slate-900 text-white border-slate-900' 
                  : 'bg-white text-slate-700 hover:text-slate-900 border-slate-200 hover:bg-slate-50'
              }`}
              title="Alternar entre modo trabajo y vista de lectura en papel"
            >
              {isReadingMode ? <Edit3 className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{isReadingMode ? 'Modo Redacción' : 'Vista Oficial'}</span>
            </button>

            {/* Propose Change / Indication button */}
            <button
              onClick={() => setShowProposalModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white rounded-xl text-xs font-bold shadow-sm transition-all hover:brightness-110 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Presentar Indicación</span>
            </button>
          </div>
        </div>

        {/* Chapter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {synthesisChapters.map((chapter, idx) => (
            <button
              key={chapter.id}
              onClick={() => setActiveChapterIndex(idx)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 border ${
                activeChapterIndex === idx
                  ? 'bg-[#4A154B] text-white border-purple-900 shadow-sm'
                  : 'bg-white text-slate-600 hover:text-slate-900 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <span>Capítulo {chapter.number}</span>
              {chapter.dissensusItems.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-rose-500" title="Contiene indicaciones en debate" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Document Content Area */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6">
        
        {/* Chapter Title */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
            Capítulo {currentChapter.number}
          </span>
          <h3 className={`text-lg font-black text-slate-900 mt-1.5 ${isReadingMode ? 'font-serif-doc' : ''}`}>
            {currentChapter.title}
          </h3>
        </div>

        {/* Text Body - Source Serif in reading mode, editable if Dirección Nacional */}
        <div className={`p-4 rounded-xl border leading-relaxed ${
          isReadingMode 
            ? 'bg-amber-50/30 border-amber-200 font-serif-doc text-base text-slate-900' 
            : 'bg-slate-50 border-slate-200 text-slate-800 text-sm'
        }`}>
          {isSecretary && !isReadingMode ? (
            <textarea
              value={currentChapter.content}
              onChange={(e) => updateChapterContent(currentChapter.id, e.target.value)}
              className="w-full h-40 bg-white border border-slate-300 rounded-lg p-3 text-slate-900 text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-[#4A154B] resize-none font-sans"
              placeholder="Escriba aquí la redacción de síntesis oficial..."
            />
          ) : (
            <p className="whitespace-pre-line leading-relaxed">
              {currentChapter.content}
            </p>
          )}

          <div className="mt-2.5 text-[11px] text-slate-500 font-mono flex items-center justify-between border-t border-slate-200 pt-2">
            <span>
              {isSecretary 
                ? 'Habilitado para edición directa por la Dirección Nacional (Secretaría de Actas)' 
                : 'Texto oficial de síntesis · Custodiado por Secretaría de Actas'}
            </span>
            <span className="font-semibold text-emerald-700">✓ Sincronizado en tiempo real</span>
          </div>
        </div>

        {/* 1. Consensus Items */}
        <div>
          <div className="flex items-center gap-2 mb-2.5">
            <BookmarkCheck className="w-4 h-4 text-purple-800" />
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-purple-900">
              Acuerdos y Consensos Ratificados ({currentChapter.consensusItems.length})
            </h4>
          </div>

          <div className="space-y-2">
            {currentChapter.consensusItems.map((item, index) => (
              <div 
                key={index}
                className="p-3 rounded-xl border border-purple-200 bg-purple-50/70 text-purple-950 text-xs flex items-start gap-3"
              >
                <div className="w-5 h-5 rounded-full bg-[#4A154B] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
                <div className="flex-1">
                  <p className="leading-snug font-medium">{item}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Dissensus Items & Proposed Indications (Borrado de apoyos) */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-rose-700">
                Disensos e Indicaciones en Debate ({currentChapter.dissensusItems.length})
              </h4>
            </div>
            <span className="text-[11px] text-slate-500">
              Requieren resolución o elevación a votación
            </span>
          </div>

          {currentChapter.dissensusItems.length === 0 ? (
            <div className="p-4 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
              No hay indicaciones pendientes en este capítulo. Pleno consenso alcanzado.
            </div>
          ) : (
            <div className="space-y-3">
              {currentChapter.dissensusItems.map((prop: ChangeProposal) => (
                <div 
                  key={prop.id}
                  className="p-4 rounded-xl border border-rose-200 bg-rose-50/60 text-slate-900 transition-all"
                >
                  <div className="flex items-start justify-between gap-3 mb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white uppercase tracking-wider">
                        Indicación
                      </span>
                      <span className="text-xs text-purple-900 font-bold">
                        {prop.authorName} ({prop.authorRegion})
                      </span>
                    </div>

                    {/* Elevate to Plenary Motion Button (Only Dirección Nacional) */}
                    {isDireccionNacional ? (
                      <button
                        onClick={() => elevateProposalToMotion(currentChapter.id, prop.id)}
                        className="flex items-center gap-1 px-3 py-1 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-[11px] font-bold rounded-lg shadow transition-transform active:scale-95 cursor-pointer"
                        title="Abrir votación parlamentaria formal para esta indicación"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5 text-purple-200" />
                        <span>Elevar a Votación</span>
                      </button>
                    ) : (
                      <span className="text-[10px] text-purple-900 font-bold bg-purple-100 px-2.5 py-0.5 rounded border border-purple-200">
                        En debate plenario
                      </span>
                    )}
                  </div>

                  {/* Proposed Text Box */}
                  <div className="p-3 rounded-lg mb-2 text-xs leading-relaxed border bg-white border-rose-200">
                    <div className="text-[10px] uppercase font-bold text-rose-700 mb-1">Texto Propuesto:</div>
                    <p className="font-semibold text-slate-900">{prop.proposedText}</p>
                  </div>

                  <p className="text-xs text-slate-700 italic mb-2">
                    <span className="font-bold text-slate-900 not-italic">Fundamentación:</span> {prop.justification}
                  </p>

                  <div className="text-[11px] text-slate-400 font-mono text-right pt-1 border-t border-rose-100">
                    Presentada: {new Date(prop.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Modal: Presentar Indicación / Enmienda */}
      {showProposalModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg p-6 shadow-2xl text-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-extrabold text-slate-900 mb-1">
              Presentar Nueva Indicación o Planteamiento
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Capítulo {currentChapter.number}: {currentChapter.title}
            </p>

            <form onSubmit={handleCreateProposal} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Tipo de Planteamiento
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setProposalType('DISENSO')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      proposalType === 'DISENSO'
                        ? 'bg-rose-50 border-rose-400 text-rose-800 font-extrabold'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Disenso / Enmienda</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setProposalType('CONSENSO')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      proposalType === 'CONSENSO'
                        ? 'bg-purple-50 border-purple-400 text-purple-900 font-extrabold'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Consenso Inmediato</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Texto o Redacción Propuesta
                </label>
                <textarea
                  value={proposalText}
                  onChange={(e) => setProposalText(e.target.value)}
                  rows={3}
                  required
                  placeholder="Redacte el texto, modificación o párrafo específico..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Fundamentación Política y Regional
                </label>
                <textarea
                  value={proposalJustification}
                  onChange={(e) => setProposalJustification(e.target.value)}
                  rows={2}
                  required
                  placeholder="Argumente la razón del planteamiento para la síntesis..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-900 focus:outline-none focus:border-[#4A154B] focus:bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowProposalModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#4A154B] hover:bg-[#5E1B5F] text-white text-xs font-bold rounded-xl shadow transition-all cursor-pointer"
                >
                  Ingresar Indicación
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
