import React, { useMemo, useState } from 'react';
import { usePlenario } from '../../context/PlenarioContext';
import { Delegate, MotionVote, Motion } from '../../types/plenario';
import { Radio, CheckCircle, XCircle, MinusCircle, Clock } from 'lucide-react';

export const HemicicloMiniBox: React.FC = () => {
  const { delegates, activeMotion, motionsHistory } = usePlenario();
  const [hoveredDel, setHoveredDel] = useState<{ delegate: Delegate; vote?: MotionVote } | null>(null);

  // Determine which motion is being reflected:
  // "Idea que sea la que esta en votacion y cuando no se esta votando la ultima que se voto"
  const motionReflected: Motion = useMemo(() => {
    // 1. If active motion is in voting, that's the one!
    if (activeMotion && activeMotion.status === 'VOTING') {
      return activeMotion;
    }
    // 2. Any motion in history that is currently in voting
    const votingMotion = motionsHistory.find(m => m.status === 'VOTING');
    if (votingMotion) {
      return votingMotion;
    }
    // 3. Otherwise, the most recently voted/closed motion in history
    const lastVoted = motionsHistory.find(m => 
      m.status === 'APPROVED' || m.status === 'REJECTED' || m.status === 'CLOSED'
    );
    if (lastVoted) {
      return lastVoted;
    }
    return activeMotion || motionsHistory[0];
  }, [activeMotion, motionsHistory]);

  const isLiveVoting = motionReflected.status === 'VOTING';

  const votingDelegates = useMemo(() => {
    return delegates.filter(d => d.role === 'DELEGATE');
  }, [delegates]);

  const votes = motionReflected.votes || {};

  // Arc layout calculation for voting seats in 3 concentric arcs (6, 8, 10)
  const hemicircleNodes = useMemo(() => {
    const total = votingDelegates.length;
    const arcs = [
      { radius: 68, count: 6 },
      { radius: 98, count: 8 },
      { radius: 128, count: 10 }
    ];

    const nodes: Array<{
      delegate: Delegate;
      x: number;
      y: number;
    }> = [];

    let currentIdx = 0;
    arcs.forEach((arc) => {
      const count = arc.count;
      for (let i = 0; i < count && currentIdx < total; i++) {
        const angleSpan = 150;
        const step = count > 1 ? angleSpan / (count - 1) : 0;
        const angleDeg = 195 + i * step;
        const angleRad = (angleDeg * Math.PI) / 180;

        const cx = 150;
        const cy = 138;
        const x = cx + arc.radius * Math.cos(angleRad);
        const y = cy + arc.radius * Math.sin(angleRad);

        nodes.push({
          delegate: votingDelegates[currentIdx],
          x,
          y
        });
        currentIdx++;
      }
    });

    return nodes;
  }, [votingDelegates]);

  const getNodeColor = (delId: string) => {
    const v = votes[delId];
    if (!v) return '#CBD5E1'; // Pending (Light slate)
    if (v.vote === 'A_FAVOR') return '#4A154B'; // Morado Cardenal
    if (v.vote === 'EN_CONTRA') return '#DC2626'; // Rojo
    return '#64748B'; // Gris Abstención
  };

  const votesList = Object.values(votes);
  const aFavor = votesList.filter(v => v.vote === 'A_FAVOR').length;
  const enContra = votesList.filter(v => v.vote === 'EN_CONTRA').length;
  const abstencion = votesList.filter(v => v.vote === 'ABSTENCION').length;
  const totalCast = votesList.length;
  const pendientes = Math.max(0, votingDelegates.length - totalCast);

  return (
    <div className="flex flex-col h-full w-full min-w-0 bg-white border border-slate-200 rounded-2xl shadow-sm p-3 overflow-hidden">
      
      {/* Header: Indicates clearly which motion is being reflected in real time */}
      <div className="flex flex-col gap-1 pb-2 border-b border-slate-100 shrink-0">
        <div className="flex items-center justify-between gap-1.5">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="w-2 h-2 rounded-full bg-[#4A154B] shrink-0" />
            <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider truncate">
              HEMICICLO
            </h3>
          </div>

          {/* Dynamic Badge: Live Voting vs Last Voted */}
          <div className="shrink-0">
            {isLiveVoting ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-ping" />
                <span>En Votación en Vivo</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-50 text-purple-900 border border-purple-200">
                <Clock className="w-3 h-3 text-[#4A154B]" />
                <span>Última Votación Reflejada</span>
              </span>
            )}
          </div>
        </div>

        {/* Reflected Motion Title & Code */}
        <div className="flex items-center justify-between gap-2 text-[11px] leading-tight">
          <div className="text-slate-800 font-bold truncate">
            <span className="text-purple-900 font-mono font-extrabold mr-1">[{motionReflected.code}]</span>
            <span>{motionReflected.title}</span>
          </div>
          <span className={`text-[10px] font-bold shrink-0 ${
            motionReflected.status === 'APPROVED' ? 'text-emerald-700' :
            motionReflected.status === 'REJECTED' ? 'text-rose-700' : 'text-purple-900'
          }`}>
            {motionReflected.status === 'APPROVED' ? '✓ Aprobada' : 
             motionReflected.status === 'REJECTED' ? '✗ Rechazada' : 
             '● Abierta'}
          </span>
        </div>
      </div>

      {/* Semicircular Seats Visualization with Real-Time Updates */}
      <div className="relative flex-1 flex items-center justify-center min-h-[110px] py-1">
        <svg 
          viewBox="0 0 300 160" 
          className="w-full h-full max-h-[150px] drop-shadow-xs"
        >
          {/* Guide Arcs */}
          <path d="M 82,138 A 68,68 0 0,1 218,138" fill="none" stroke="#F1F5F9" strokeWidth="2" strokeDasharray="3 3" />
          <path d="M 52,138 A 98,98 0 0,1 248,138" fill="none" stroke="#F1F5F9" strokeWidth="2" strokeDasharray="3 3" />
          <path d="M 22,138 A 128,128 0 0,1 278,138" fill="none" stroke="#F1F5F9" strokeWidth="2" strokeDasharray="3 3" />

          {/* Central Podium / Mesa Directiva Indicator */}
          <rect x="135" y="128" width="30" height="12" rx="4" fill="#4A154B" />
          <text x="150" y="136" textAnchor="middle" fill="#FFFFFF" fontSize="7" fontWeight="bold">MESA</text>

          {/* Delegate Seat Nodes with Dynamic Colors */}
          {hemicircleNodes.map(({ delegate, x, y }) => {
            const v = votes[delegate.id];
            const color = getNodeColor(delegate.id);
            const isHovered = hoveredDel?.delegate.id === delegate.id;

            return (
              <g 
                key={delegate.id}
                onMouseEnter={() => setHoveredDel({ delegate, vote: v })}
                onMouseLeave={() => setHoveredDel(null)}
                className="cursor-pointer transition-transform duration-200"
              >
                <circle
                  cx={x}
                  cy={y}
                  r={isHovered ? 8 : 6.5}
                  fill={color}
                  stroke="#FFFFFF"
                  strokeWidth="1.5"
                  className="transition-all duration-300"
                />
              </g>
            );
          })}
        </svg>

        {/* Hover delegate tooltip overlay */}
        {hoveredDel && (
          <div className="absolute bottom-1 inset-x-2 bg-slate-900/95 backdrop-blur-xs text-white p-2 rounded-xl text-center text-[10px] pointer-events-none animate-in fade-in duration-100 shadow-lg border border-slate-700 z-20">
            <div className="font-bold text-white text-[11px]">{hoveredDel.delegate.name}</div>
            <div className="text-slate-300 text-[10px]">{hoveredDel.delegate.region} · {hoveredDel.delegate.organization}</div>
            <div className="mt-0.5">
              <span className={`font-black uppercase tracking-wider px-2 py-0.5 rounded text-[9px] ${
                hoveredDel.vote?.vote === 'A_FAVOR' ? 'bg-[#4A154B] text-white' :
                hoveredDel.vote?.vote === 'EN_CONTRA' ? 'bg-rose-600 text-white' :
                hoveredDel.vote?.vote === 'ABSTENCION' ? 'bg-slate-600 text-white' : 'bg-slate-700 text-amber-300'
              }`}>
                {hoveredDel.vote ? hoveredDel.vote.vote.replace('_', ' ') : 'VOTO PENDIENTE'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Mini Live Tally Bar */}
      <div className="flex items-center justify-between text-[10px] font-mono font-medium text-slate-700 pt-1.5 border-t border-slate-100 shrink-0">
        <span className="flex items-center gap-1 font-bold text-purple-950">
          <span className="w-2.5 h-2.5 rounded-full bg-[#4A154B]" />
          <span>{aFavor} Fav</span>
        </span>
        <span className="flex items-center gap-1 font-bold text-rose-700">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
          <span>{enContra} Con</span>
        </span>
        <span className="flex items-center gap-1 font-bold text-slate-700">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
          <span>{abstencion} Abs</span>
        </span>
        <span className="flex items-center gap-1 font-semibold text-slate-400">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
          <span>{pendientes} Pend</span>
        </span>
      </div>

    </div>
  );
};
