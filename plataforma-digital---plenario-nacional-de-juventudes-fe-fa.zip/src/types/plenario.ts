export type UserRole = 'DELEGATE' | 'DIRECCION_NACIONAL' | 'MODERATOR' | 'SECRETARY' | 'ADMIN';

export type GenderIdentity = 'Femenino' | 'Masculino' | 'No-binario';

export type ChileanRegion = 
  | 'Arica y Parinacota'
  | 'Tarapacá'
  | 'Antofagasta'
  | 'Atacama'
  | 'Coquimbo'
  | 'Valparaíso'
  | 'Metropolitana'
  | "O'Higgins"
  | 'Maule'
  | 'Ñuble'
  | 'Biobío'
  | 'Araucanía'
  | 'Los Ríos'
  | 'Los Lagos'
  | 'Aysén'
  | 'Magallanes';

export type VoteOption = 'A_FAVOR' | 'EN_CONTRA' | 'ABSTENCION';

export interface Delegate {
  id: string;
  name: string;
  email: string;
  region: ChileanRegion;
  gender: GenderIdentity;
  role: UserRole;
  organization: string; // e.g. FECh, FEC, FEUACh, Federación UV, etc.
  avatarUrl?: string;
  isOnline: boolean;
  hasSpokenInCurrentMotion: boolean;
  lastSessionId?: string;
  ipAddress?: string;
}

export interface SpeakerQueueItem {
  id: string;
  delegateId: string;
  delegateName: string;
  region: ChileanRegion;
  gender: GenderIdentity;
  requestedAt: number; // timestamp
  priorityScore: number; // calculated by parity + regional alternation
  status: 'WAITING' | 'SPEAKING' | 'COMPLETED' | 'PASSED';
  timeAllocatedSeconds: number;
}

export interface MotionVote {
  delegateId: string;
  delegateName: string;
  region: ChileanRegion;
  vote: VoteOption;
  timestamp: number;
  digitalSignatureHash: string;
  notes?: string;
}

export type MotionStatus = 'DRAFT' | 'OPEN' | 'VOTING' | 'CLOSED' | 'APPROVED' | 'REJECTED';

export type QuorumType = 'SIMPLE_MAJORITY' | 'TWO_THIRDS';

export interface Motion {
  id: string;
  code: string; // e.g. "MOC-2026-004"
  title: string;
  description: string;
  proposedBy: string; // Delegate name & region
  status: MotionStatus;
  quorumType: QuorumType;
  createdAt: number;
  startedAt?: number;
  closedAt?: number;
  durationSeconds: number;
  votes: Record<string, MotionVote>; // delegateId -> MotionVote
  resultSummary?: {
    totalEligible: number;
    totalCast: number;
    aFavor: number;
    enContra: number;
    abstencion: number;
    percentageFavor: number;
    quorumMet: boolean;
    isApproved: boolean;
  };
}

export interface ChangeProposal {
  id: string;
  chapterId: string;
  authorId: string;
  authorName: string;
  authorRegion: ChileanRegion;
  type: 'CONSENSO' | 'DISENSO';
  originalText: string;
  proposedText: string;
  justification: string;
  status: 'PENDING' | 'IN_DEBATE' | 'ACCEPTED' | 'REJECTED';
  votesFavor: number;
  votesContra: number;
  createdAt: number;
}

export interface SynthesisChapter {
  id: string;
  number: number;
  title: string;
  content: string;
  consensusItems: string[];
  dissensusItems: ChangeProposal[];
  lastModifiedBy: string;
  lastModifiedAt: number;
}

export type OrderMotionCategory = 
  | 'MOCION_ORDEN' 
  | 'PUNTO_INFORMACION' 
  | 'CUESTION_PREVIA' 
  | 'MOCION_CENSURA' 
  | 'MESA_AYUDA';

export interface OrderMotion {
  id: string;
  delegateId: string;
  delegateName: string;
  region: ChileanRegion;
  category: OrderMotionCategory;
  message: string;
  timestamp: number;
  status: 'PENDIENTE' | 'ATENDIDA' | 'DESESTIMADA';
  resolvedBy?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  isoTime: string;
  delegateId: string;
  delegateName: string;
  ipAddress: string;
  action: string;
  details: string;
  integrityHash: string;
}

export type ActaStatus = 'BORRADOR' | 'EN_REVISION' | 'CERTIFICADA';

export interface ActaSignature {
  signerName: string;
  role: string;
  timestamp: number;
  token: string;
  status: 'FIRMADO' | 'PENDIENTE';
}

export interface Acta {
  id: string;
  code: string; // e.g. "ACTA-2026-001"
  sessionTitle: string;
  sessionType: 'ORDINARIA' | 'EXTRAORDINARIA' | 'CONSTITUTIVA';
  date: string;
  timeStart: string;
  timeEnd?: string;
  location: string;
  quorumInstallationText: string;
  accreditedDelegatesCount: number;
  agendaTopics: string[];
  bodyContent: string;
  conclusions: string[];
  votedMotionIds: string[];
  status: ActaStatus;
  digitalSignatures: ActaSignature[];
  integrityHash: string;
  lastModifiedAt: number;
  lastModifiedBy: string;
}
