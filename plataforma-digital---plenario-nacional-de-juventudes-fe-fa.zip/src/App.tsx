/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PlenarioProvider, usePlenario } from './context/PlenarioContext';
import { Header } from './components/Header';
import { VotacionBox } from './components/plenario/VotacionBox';
import { HemicicloMiniBox } from './components/plenario/HemicicloMiniBox';
import { VideoBox } from './components/plenario/VideoBox';
import { SintesisBox } from './components/plenario/SintesisBox';
import { ControlPalabraBox } from './components/plenario/ControlPalabraBox';
import { TiempoPalabraBox } from './components/plenario/TiempoPalabraBox';
import { AdminActasView } from './components/admin/AdminActasView';
import { PadronManager } from './components/admin/PadronManager';
import { LoginModal } from './components/LoginModal';
import { VolumeX, WifiOff, AlertCircle, Vote } from 'lucide-react';

const PlenarioAppContent: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    currentUser, 
    forceMuted, 
    lowBandwidthMode, 
    isDireccionNacional, 
    activeMotion,
    showLoginModal,
    setShowLoginModal
  } = usePlenario();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-[#4A154B] selection:text-white">
      
      {/* Header Bar */}
      <Header />

      {/* Global Status Notices */}
      <div className="no-print">
        {/* Banner para usuarios que ingresan por primera vez o no están acreditados */}
        {!currentUser && (
          <div className="bg-gradient-to-r from-[#4A154B] to-[#D32F2F] text-white px-4 py-2 flex items-center justify-between text-xs font-bold shadow-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" />
              <span>Modo Observador: Ingrese como DNE (<strong className="font-mono">fe@frenteampliochile.cl</strong>) o con su correo de delegada/o para habilitar voz y voto.</span>
            </div>
            <button
              onClick={() => setShowLoginModal(true)}
              className="px-3 py-1 bg-white text-[#4A154B] hover:bg-purple-50 rounded-lg text-xs font-black cursor-pointer transition-all shadow-xs shrink-0"
            >
              Acreditarse Ahora
            </button>
          </div>
        )}
        {forceMuted && (
          <div className="bg-rose-100 border-b border-rose-300 px-4 py-2 text-center text-xs font-bold text-rose-800 flex items-center justify-center gap-2">
            <VolumeX className="w-4 h-4 text-rose-600" />
            <span>Atención: La Mesa Directiva ha activado el Silencio Forzado de Sala.</span>
          </div>
        )}

        {lowBandwidthMode && (
          <div className="bg-amber-100 border-b border-amber-300 px-4 py-1.5 text-center text-xs font-medium text-amber-900 flex items-center justify-center gap-2">
            <WifiOff className="w-3.5 h-3.5 text-amber-700" />
            <span>Modo Ancho de Banda Reducido activado: La transmisión se prioriza para audio y votación sin latencia.</span>
          </div>
        )}

        {/* Global Voting Alert Banner */}
        {activeMotion && activeMotion.status === 'VOTING' && activeTab !== 'plenario' && (
          <div className="bg-purple-100 border-b border-purple-300 px-4 py-2 flex items-center justify-between gap-3 text-xs text-purple-950 font-bold max-w-7xl mx-auto w-full">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse shrink-0" />
              <span>Votación en Curso: <strong>{activeMotion.code} - {activeMotion.title}</strong></span>
            </div>
            <button
              onClick={() => setActiveTab('plenario')}
              className="px-3 py-1 bg-[#4A154B] hover:bg-[#5E1B5F] text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1 shrink-0"
            >
              <Vote className="w-3.5 h-3.5" />
              <span>Ir a Votar / Rectificar</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <main className={`flex-1 w-full mx-auto min-w-0 ${
        activeTab === 'plenario' 
          ? 'max-w-[1720px] p-2 md:p-2.5 lg:p-3 h-auto md:h-[calc(100vh-58px)] overflow-y-auto md:overflow-hidden flex flex-col' 
          : 'max-w-7xl p-4 lg:p-6 overflow-y-auto'
      }`}>
        
        {/* Tab 1: Plenario Deliberativo (Optimizado para Tablet/iPad como formato PC/Mac: Superior Síntesis + Video; Inferior Votación + Hemiciclo + Control Palabra) */}
        {activeTab === 'plenario' && (
          <div className="flex flex-col h-full w-full gap-2 md:gap-2.5 min-h-0 overflow-y-auto md:overflow-hidden">
            
            {/* Contenedor Principal */}
            <div className="flex-1 flex flex-col gap-2 md:gap-2.5 min-w-0 h-full overflow-hidden">
              
              {/* Sección Superior: SÍNTESIS NACIONAL (5 cols) y VIDEO WebRTC (7 cols) */}
              <div className="flex-1 min-h-[320px] md:min-h-0 grid grid-cols-1 md:grid-cols-12 gap-2 md:gap-2.5 overflow-hidden">
                
                {/* Superior Izquierda (5 cols): SÍNTESIS NACIONAL */}
                <div className="md:col-span-5 h-full min-h-0 flex flex-col overflow-hidden">
                  <SintesisBox />
                </div>

                {/* Superior Derecha (7 cols): Pantalla de Video WebRTC con botones [CAM] e [IMG] */}
                <div className="md:col-span-7 h-full min-h-0 flex flex-col overflow-hidden">
                  <VideoBox />
                </div>
              </div>

              {/* Sección Inferior: VOTACIÓN (4 cols) | HEMICICLO (4 cols) | TIEMPO PALABRA + CONTROL DE PALABRA (4 cols) */}
              <div className="h-auto md:h-[260px] lg:h-[275px] shrink-0 grid grid-cols-1 md:grid-cols-12 gap-2 md:gap-2.5 overflow-hidden">
                
                {/* Inferior Izquierda (4 cols): VOTACIÓN con escrutinio en tiempo real */}
                <div className="md:col-span-4 h-[250px] md:h-full min-h-0">
                  <VotacionBox />
                </div>

                {/* Inferior Centro (4 cols): HEMICICLO PARLAMENTARIO */}
                <div className="md:col-span-4 h-[250px] md:h-full min-h-0">
                  <HemicicloMiniBox />
                </div>

                {/* Inferior Derecha (4 cols): TIEMPO DE PALABRA + CONTROL DE PALABRA */}
                <div className="md:col-span-4 h-[250px] md:h-full min-h-0 flex flex-col gap-1.5 md:gap-2 overflow-hidden">
                  {/* Tiempo de palabra compacto */}
                  <div className="shrink-0">
                    <TiempoPalabraBox />
                  </div>

                  {/* Cola de oradores y gestión de palabra */}
                  <div className="flex-1 min-h-0">
                    <ControlPalabraBox />
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}


        {/* Tab 2: Secretaría Técnica & Repositorio de Actas Oficiales (Accesible para todos los usuarios para revisión) */}
        {activeTab === 'actas' && (
          <div className="w-full min-w-0">
            <AdminActasView />
          </div>
        )}

        {/* Tab 3: Padrón Electoral y Administración (Exclusivo para Secretaría Técnica) */}
        {activeTab === 'padron' && (
          <div className="w-full min-w-0">
            <PadronManager />
          </div>
        )}

      </main>

      {/* Login / Acreditación Modal */}
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
      />

    </div>
  );
};

export default function App() {
  return (
    <PlenarioProvider>
      <PlenarioAppContent />
    </PlenarioProvider>
  );
}
