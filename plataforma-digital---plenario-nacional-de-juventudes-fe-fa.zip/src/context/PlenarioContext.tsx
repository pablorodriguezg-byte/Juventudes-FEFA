import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Delegate, 
  Motion, 
  SynthesisChapter, 
  OrderMotion, 
  AuditLogEntry, 
  VoteOption, 
  SpeakerQueueItem,
  ChangeProposal,
  UserRole,
  ChileanRegion,
  OrderMotionCategory,
  Acta
} from '../types/plenario';
import { 
  INITIAL_DELEGATES, 
  INITIAL_MOTIONS, 
  INITIAL_SYNTHESIS_CHAPTERS, 
  INITIAL_ORDER_MOTIONS, 
  INITIAL_AUDIT_LOGS,
  INITIAL_ACTAS
} from '../data/initialData';
import confetti from 'canvas-confetti';

interface PlenarioContextType {
  currentUser: Delegate | null;
  setCurrentUser: (delegate: Delegate | null) => void;
  delegates: Delegate[];
  activeTab: 'plenario' | 'actas' | 'padron';
  setActiveTab: (tab: 'plenario' | 'actas' | 'padron') => void;
  activeMotion: Motion;
  activeMotionId: string;
  setActiveMotionId: (id: string) => void;
  motionsHistory: Motion[];
  speakerQueue: SpeakerQueueItem[];
  activeSpeaker: SpeakerQueueItem | null;
  timerSeconds: number;
  timerTotal: number;
  isTimerRunning: boolean;
  lowBandwidthMode: boolean;
  setLowBandwidthMode: (enabled: boolean) => void;
  forceMuted: boolean;
  setForceMuted: (muted: boolean) => void;
  synthesisChapters: SynthesisChapter[];
  orderMotions: OrderMotion[];
  auditLogs: AuditLogEntry[];
  
  // Actas System
  actas: Acta[];
  activeActaId: string;
  setActiveActaId: (id: string) => void;
  createActa: (data: Partial<Acta>) => Acta;
  updateActa: (id: string, updates: Partial<Acta>) => void;
  deleteActa: (id: string) => { success: boolean; error?: string };
  certifyActa: (id: string) => void;
  
  // Role helpers
  isDireccionNacional: boolean;
  isSecretariaTecnica: boolean;
  isDelegate: boolean;
  canVote: boolean;
  
  // Modal de Acreditación
  showLoginModal: boolean;
  setShowLoginModal: (show: boolean) => void;
  
  // Actions
  loginWithEmail: (email: string) => { success: boolean; error?: string };
  logout: () => void;
  castVote: (option: VoteOption, notes?: string) => void;
  openVotingForMotion: (motionId: string) => void;
  closeVotingForMotion: (motionId: string) => void;
  createNewMotion: (
    title: string, 
    description: string, 
    quorumType: 'SIMPLE_MAJORITY' | 'TWO_THIRDS',
    immediateLaunch?: boolean,
    durationSeconds?: number
  ) => Motion | undefined;
  
  // Delegate Management (Secretaría Técnica)
  deleteDelegate: (delegateId: string) => { success: boolean; error?: string };
  updateDelegate: (delegateId: string, updates: Partial<Delegate>) => { success: boolean; error?: string };
  addDelegate: (newDel: Omit<Delegate, 'id' | 'isOnline' | 'hasSpokenInCurrentMotion'>) => void;
  
  // Speaker & Timer controls
  requestWord: () => void;
  withdrawWord: () => void;
  takeFloorAsPresidency: () => void;
  giveWordToSpeaker: (queueItemId: string) => void;
  finishSpeaking: () => void;
  startTimer: () => void;
  pauseTimer: () => void;
  resetTimer: (customSeconds?: number) => void;
  addThirtySeconds: () => void;
  
  // Synthesis document
  updateChapterContent: (chapterId: string, newContent: string) => void;
  addChangeProposal: (chapterId: string, proposedText: string, justification: string, type: 'CONSENSO' | 'DISENSO') => void;
  voteChangeProposal: (chapterId: string, proposalId: string, vote: 'FAVOR' | 'CONTRA') => void;
  elevateProposalToMotion: (chapterId: string, proposalId: string) => void;
  
  // Order motions
  sendOrderMotion: (category: OrderMotionCategory, message: string) => void;
  resolveOrderMotion: (id: string, newStatus: 'ATENDIDA' | 'DESESTIMADA') => void;
  
  // Padron & CSV
  importDelegatesCSV: (csvText: string) => { success: boolean; count: number; error?: string };
  exportPadronCSV: () => void;
  exportActaCSV: () => void;
  addAuditLog: (action: string, details: string) => void;
  resetAllData: () => void;
}

const PlenarioContext = createContext<PlenarioContextType | undefined>(undefined);

// Web Audio sound synthesizer helper for countdown alerts
const playTone = (frequency: number, type: OscillatorType, duration: number) => {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    // Audio might be constrained if user hasn't interacted yet
  }
};

export const PlenarioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [delegates, setDelegates] = useState<Delegate[]>(() => {
    const saved = localStorage.getItem('fe_fa_delegates');
    if (saved) {
      let parsed: Delegate[] = JSON.parse(saved);
      // Asegurar que la DNE (fe@frenteampliochile.cl) siempre esté en el padrón
      if (!parsed.some(d => d.email.toLowerCase() === 'fe@frenteampliochile.cl')) {
        const dne = INITIAL_DELEGATES.find(d => d.email === 'fe@frenteampliochile.cl');
        if (dne) parsed = [dne, ...parsed];
      }
      // Asegurar que la Secretaría Técnica (secretaria@juventudes.cl) esté actualizada en el padrón
      const secIdx = parsed.findIndex(d => d.role === 'SECRETARY' || d.email.toLowerCase().includes('secretaria'));
      if (secIdx !== -1) {
        parsed[secIdx] = {
          ...parsed[secIdx],
          name: 'Secretaría Técnica FE-FA',
          email: 'secretaria@juventudes.cl',
          role: 'SECRETARY',
          organization: 'Secretaría Técnica Nacional'
        };
      } else {
        const sec = INITIAL_DELEGATES.find(d => d.email === 'secretaria@juventudes.cl');
        if (sec) parsed = [sec, ...parsed];
      }
      return parsed;
    }
    return INITIAL_DELEGATES;
  });

  const [currentUser, setCurrentUser] = useState<Delegate | null>(() => {
    const savedId = localStorage.getItem('fe_fa_current_user_id');
    if (savedId) {
      const match = INITIAL_DELEGATES.find(d => d.id === savedId);
      if (match) return match;
    }
    // Si no hay sesión guardada (ingresa por primera vez a la web), queda nulo para que deba acreditarse
    return null;
  });

  const [showLoginModal, setShowLoginModal] = useState<boolean>(() => {
    // Si entra por primera vez, debe poder acreditarse de inmediato
    return !localStorage.getItem('fe_fa_current_user_id');
  });

  const [activeTab, setActiveTab] = useState<'plenario' | 'actas' | 'padron'>('plenario');
  const [motionsHistory, setMotionsHistory] = useState<Motion[]>(() => {
    const saved = localStorage.getItem('fe_fa_motions');
    return saved ? JSON.parse(saved) : INITIAL_MOTIONS;
  });
  const [activeMotionId, setActiveMotionId] = useState<string>('moc-002');
  
  const [lowBandwidthMode, setLowBandwidthMode] = useState<boolean>(false);
  const [forceMuted, setForceMuted] = useState<boolean>(false);

  // Speaker queue state
  const [speakerQueue, setSpeakerQueue] = useState<SpeakerQueueItem[]>([
    {
      id: 'sq-1',
      delegateId: 'del-05',
      delegateName: 'Sofía Carvajal Araya',
      region: 'Antofagasta',
      gender: 'Femenino',
      requestedAt: Date.now() - 120000,
      priorityScore: 85,
      status: 'SPEAKING',
      timeAllocatedSeconds: 120
    },
    {
      id: 'sq-2',
      delegateId: 'del-06',
      delegateName: 'Joaquín Navarrete Pino',
      region: 'Araucanía',
      gender: 'Masculino',
      requestedAt: Date.now() - 90000,
      priorityScore: 65,
      status: 'WAITING',
      timeAllocatedSeconds: 120
    },
    {
      id: 'sq-3',
      delegateId: 'del-07',
      delegateName: 'Alex Cárdenas Muñoz',
      region: 'Los Ríos',
      gender: 'No-binario',
      requestedAt: Date.now() - 45000,
      priorityScore: 80,
      status: 'WAITING',
      timeAllocatedSeconds: 120
    }
  ]);

  const [activeSpeaker, setActiveSpeaker] = useState<SpeakerQueueItem | null>(speakerQueue[0] || null);

  // Timer state
  const [timerTotal, setTimerTotal] = useState<number>(120);
  const [timerSeconds, setTimerSeconds] = useState<number>(78);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);

  // Synthesis and other state
  const [synthesisChapters, setSynthesisChapters] = useState<SynthesisChapter[]>(() => {
    const saved = localStorage.getItem('fe_fa_synthesis');
    return saved ? JSON.parse(saved) : INITIAL_SYNTHESIS_CHAPTERS;
  });

  const [orderMotions, setOrderMotions] = useState<OrderMotion[]>(() => {
    const saved = localStorage.getItem('fe_fa_order_motions');
    return saved ? JSON.parse(saved) : INITIAL_ORDER_MOTIONS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    const saved = localStorage.getItem('fe_fa_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  // Actas State
  const [actas, setActas] = useState<Acta[]>(() => {
    const saved = localStorage.getItem('fe_fa_actas');
    return saved ? JSON.parse(saved) : INITIAL_ACTAS;
  });
  const [activeActaId, setActiveActaId] = useState<string>('acta-002');

  // Save changes
  useEffect(() => {
    localStorage.setItem('fe_fa_delegates', JSON.stringify(delegates));
  }, [delegates]);

  useEffect(() => {
    localStorage.setItem('fe_fa_motions', JSON.stringify(motionsHistory));
  }, [motionsHistory]);

  useEffect(() => {
    localStorage.setItem('fe_fa_synthesis', JSON.stringify(synthesisChapters));
  }, [synthesisChapters]);

  useEffect(() => {
    localStorage.setItem('fe_fa_order_motions', JSON.stringify(orderMotions));
  }, [orderMotions]);

  useEffect(() => {
    localStorage.setItem('fe_fa_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem('fe_fa_actas', JSON.stringify(actas));
  }, [actas]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('fe_fa_current_user_id', currentUser.id);
    } else {
      localStorage.removeItem('fe_fa_current_user_id');
    }
  }, [currentUser]);

  // Current active motion
  const activeMotion = useMemo(() => {
    const found = motionsHistory.find(m => m.id === activeMotionId);
    return found || motionsHistory[0];
  }, [motionsHistory, activeMotionId]);

  // Add audit log helper
  const addAuditLog = useCallback((action: string, details: string) => {
    const newEntry: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      isoTime: new Date().toISOString(),
      delegateId: currentUser ? currentUser.id : 'SYSTEM',
      delegateName: currentUser ? `${currentUser.name} (${currentUser.role})` : 'Sistema Automatizado',
      ipAddress: currentUser?.ipAddress || '190.161.42.1',
      action,
      details,
      integrityHash: Array.from(action + details + Date.now())
        .reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 0)
        .toString(16) + '...sha256'
    };
    setAuditLogs(prev => [newEntry, ...prev.slice(0, 199)]);
  }, [currentUser]);

  // Delete delegate (Secretaría Técnica / Admin)
  const deleteDelegate = useCallback((delegateId: string): { success: boolean; error?: string } => {
    if (!currentUser || (currentUser.role !== 'SECRETARY' && currentUser.role !== 'ADMIN')) {
      return { success: false, error: 'Acceso no autorizado. Solo la Secretaría Técnica puede gestionar y eliminar usuarios del padrón.' };
    }

    if (currentUser.id === delegateId) {
      return { success: false, error: 'No puede eliminar su propia cuenta activa del padrón.' };
    }

    const target = delegates.find(d => d.id === delegateId);
    if (!target) {
      return { success: false, error: 'Delegado/a no encontrado en el padrón.' };
    }

    // Remove from delegates list
    setDelegates(prev => prev.filter(d => d.id !== delegateId));

    // Remove from speaker queue if present
    setSpeakerQueue(prev => prev.filter(item => item.delegateId !== delegateId));
    if (activeSpeaker?.delegateId === delegateId) {
      setActiveSpeaker(null);
      setIsTimerRunning(false);
    }

    addAuditLog('ELIMINACION_DELEGADO', `${currentUser.name} (Secretaría Técnica) eliminó del padrón a ${target.name} (${target.region} - ${target.organization})`);
    return { success: true };
  }, [currentUser, delegates, activeSpeaker, addAuditLog]);

  // Update delegate (Secretaría Técnica / Admin)
  const updateDelegate = useCallback((delegateId: string, updates: Partial<Delegate>): { success: boolean; error?: string } => {
    if (!currentUser || (currentUser.role !== 'SECRETARY' && currentUser.role !== 'ADMIN')) {
      return { success: false, error: 'Acceso no autorizado. Solo la Secretaría Técnica puede modificar usuarios en el padrón.' };
    }

    const target = delegates.find(d => d.id === delegateId);
    if (!target) {
      return { success: false, error: 'Usuario no encontrado en el padrón.' };
    }

    setDelegates(prev => prev.map(d => d.id === delegateId ? { ...d, ...updates } : d));
    addAuditLog('MODIFICACION_USUARIO', `${currentUser.name} (Secretaría Técnica) modificó los datos de ${target.name} (${target.email})`);
    return { success: true };
  }, [currentUser, delegates, addAuditLog]);

  // Add delegate manually (Secretaría Técnica / Admin)
  const addDelegate = useCallback((newDel: Omit<Delegate, 'id' | 'isOnline' | 'hasSpokenInCurrentMotion'>) => {
    const id = `del-${Date.now()}`;
    const delegate: Delegate = {
      ...newDel,
      id,
      isOnline: true,
      hasSpokenInCurrentMotion: false,
      ipAddress: `190.161.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`
    };
    setDelegates(prev => [delegate, ...prev]);
    addAuditLog('ALTA_DELEGADO', `Acreditación individual agregada por Secretaría Técnica: ${delegate.name} (${delegate.region})`);
  }, [addAuditLog]);

  // Timer interval
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(prev => {
          if (prev === 21) {
            playTone(440, 'sine', 0.2);
          }
          if (prev <= 1) {
            playTone(880, 'triangle', 0.5);
            setTimeout(() => playTone(587.33, 'triangle', 0.8), 250);
            setIsTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  // Parity & Regional Alternance Algorithm for Word Requests
  const calculatePriority = useCallback((delegate: Delegate, lastSpeaker?: SpeakerQueueItem | null): number => {
    let score = 50;

    // Gender Parity Bonus: Alternate gender from previous speaker
    if (lastSpeaker) {
      if (lastSpeaker.gender === 'Masculino' && delegate.gender === 'Femenino') score += 30;
      else if (lastSpeaker.gender === 'Masculino' && delegate.gender === 'No-binario') score += 25;
      else if (lastSpeaker.gender === 'Femenino' && delegate.gender === 'Masculino') score += 20;
    } else {
      if (delegate.gender === 'Femenino') score += 15;
    }

    // Regional Alternance: Prioritize regions from extreme zones
    const extremeRegions: ChileanRegion[] = ['Arica y Parinacota', 'Tarapacá', 'Aysén', 'Magallanes'];
    if (extremeRegions.includes(delegate.region)) {
      score += 20;
    }

    if (!delegate.hasSpokenInCurrentMotion) {
      score += 15;
    }

    return score;
  }, []);

  const requestWord = useCallback(() => {
    if (!currentUser) return;
    if (speakerQueue.some(item => item.delegateId === currentUser.id && item.status !== 'COMPLETED')) {
      return;
    }

    const priority = calculatePriority(currentUser, activeSpeaker);
    const newItem: SpeakerQueueItem = {
      id: `sq-${Date.now()}`,
      delegateId: currentUser.id,
      delegateName: currentUser.name,
      region: currentUser.region,
      gender: currentUser.gender,
      requestedAt: Date.now(),
      priorityScore: priority,
      status: 'WAITING',
      timeAllocatedSeconds: 120
    };

    setSpeakerQueue(prev => {
      const updated = [...prev, newItem];
      return updated.sort((a, b) => {
        if (a.status === 'SPEAKING') return -1;
        if (b.status === 'SPEAKING') return 1;
        return b.priorityScore - a.priorityScore;
      });
    });

    addAuditLog('SOLICITUD_PALABRA', `${currentUser.name} (${currentUser.region}) solicitó la palabra. Prioridad paritaria: ${priority}`);
  }, [currentUser, activeSpeaker, speakerQueue, calculatePriority, addAuditLog]);

  const withdrawWord = useCallback(() => {
    if (!currentUser) return;
    setSpeakerQueue(prev => prev.filter(item => item.delegateId !== currentUser.id || item.status === 'SPEAKING'));
    addAuditLog('RETIRO_PALABRA', `${currentUser.name} bajó la mano`);
  }, [currentUser, addAuditLog]);

  const giveWordToSpeaker = useCallback((queueItemId: string) => {
    const target = speakerQueue.find(i => i.id === queueItemId);
    if (!target) return;

    setSpeakerQueue(prev => prev.map(item => {
      if (item.id === queueItemId) return { ...item, status: 'SPEAKING' };
      if (item.status === 'SPEAKING') return { ...item, status: 'COMPLETED' };
      return item;
    }));

    setActiveSpeaker({ ...target, status: 'SPEAKING' });
    setTimerSeconds(target.timeAllocatedSeconds || 120);
    setTimerTotal(target.timeAllocatedSeconds || 120);
    setIsTimerRunning(true);

    addAuditLog('CONCESION_PALABRA', `Mesa Directiva concede la palabra a ${target.delegateName} (${target.region}) por 2:00 min.`);
  }, [speakerQueue, addAuditLog]);

  const finishSpeaking = useCallback(() => {
    if (activeSpeaker) {
      setSpeakerQueue(prev => prev.map(i => i.id === activeSpeaker.id ? { ...i, status: 'COMPLETED' } : i));
      addAuditLog('FIN_INTERVENCION', `Concluyó la intervención de ${activeSpeaker.delegateName}`);
      setActiveSpeaker(null);
      setIsTimerRunning(false);
      setTimerSeconds(120);
    }
  }, [activeSpeaker, addAuditLog]);

  const startTimer = useCallback(() => setIsTimerRunning(true), []);
  const pauseTimer = useCallback(() => setIsTimerRunning(false), []);
  const resetTimer = useCallback((customSeconds = 120) => {
    setTimerSeconds(customSeconds);
    setTimerTotal(customSeconds);
    setIsTimerRunning(false);
  }, []);
  const addThirtySeconds = useCallback(() => {
    setTimerSeconds(prev => prev + 30);
    setTimerTotal(prev => prev + 30);
  }, []);

  const takeFloorAsPresidency = useCallback(() => {
    if (!currentUser) return;
    const item: SpeakerQueueItem = {
      id: `sq-mesa-${Date.now()}`,
      delegateId: currentUser.id,
      delegateName: `${currentUser.name} (Dirección Nacional)`,
      region: currentUser.region,
      gender: currentUser.gender,
      requestedAt: Date.now(),
      priorityScore: 999,
      status: 'SPEAKING',
      timeAllocatedSeconds: 180
    };
    setActiveSpeaker(item);
    setTimerSeconds(180);
    setTimerTotal(180);
    setIsTimerRunning(true);
    addAuditLog('INTERVENCION_MESA', `La Dirección Nacional (${currentUser.name}) hace uso de la palabra para presidir y orientar el debate.`);
  }, [currentUser, addAuditLog]);

  // Helper to identify unique browser tab
  const getTabSessionId = useCallback((): string => {
    if (typeof window === 'undefined') return 'server';
    let id = sessionStorage.getItem('fe_fa_tab_session_id');
    if (!id) {
      id = `tab-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      sessionStorage.setItem('fe_fa_tab_session_id', id);
    }
    return id;
  }, []);

  // Login & Session handling
  const loginWithEmail = useCallback((email: string): { success: boolean; error?: string } => {
    const clean = email.trim().toLowerCase();
    if (!clean) {
      return { success: false, error: 'Por favor ingrese su correo institucional acreditado.' };
    }
    
    // Buscar en padrón activo o padrón base
    let found = delegates.find(d => d.email.toLowerCase() === clean) ||
                INITIAL_DELEGATES.find(d => d.email.toLowerCase() === clean);

    // Búsqueda específica solicitada para la Secretaría Técnica: secretaria@juventudes.cl
    if (!found && (clean === 'secretaria@juventudes.cl' || clean.includes('secretaria@juventudes') || clean === 'secretariatecnica@fe-fa.cl')) {
      found = delegates.find(d => d.email === 'secretaria@juventudes.cl') ||
              delegates.find(d => d.role === 'SECRETARY') ||
              INITIAL_DELEGATES.find(d => d.email === 'secretaria@juventudes.cl') ||
              INITIAL_DELEGATES.find(d => d.role === 'SECRETARY');
    }

    // Búsqueda específica solicitada para la DNE: fe@frenteampliochile.cl
    if (!found && (clean === 'fe@frenteampliochile.cl' || clean.includes('fe@frenteamplio') || clean.includes('dne@frenteamplio'))) {
      found = INITIAL_DELEGATES.find(d => d.email === 'fe@frenteampliochile.cl') || 
              delegates.find(d => d.role === 'DIRECCION_NACIONAL') ||
              INITIAL_DELEGATES[0];
    }

    if (!found) {
      return { 
        success: false, 
        error: 'El correo ingresado no se encuentra registrado en el Padrón Oficial. Verifique la dirección o contacte a la Secretaría Técnica.' 
      };
    }

    // Regla estricta de usuario único para Secretaría Técnica
    const isTargetSecretary = found.role === 'SECRETARY' || found.role === 'ADMIN' || found.email.toLowerCase() === 'secretaria@juventudes.cl';
    if (isTargetSecretary) {
      const activeLock = localStorage.getItem('fe_fa_secretaria_tecnica_session');
      const currentTab = getTabSessionId();
      if (activeLock) {
        try {
          const lockData = JSON.parse(activeLock);
          const now = Date.now();
          // Sesión activa en otra pestaña o navegador hace menos de 10 minutos
          if (lockData.active && lockData.tabId && lockData.tabId !== currentTab && (now - (lockData.lastHeartbeat || 0)) < 10 * 60 * 1000) {
            return {
              success: false,
              error: `Acceso no permitido: Ya existe una sesión activa de la Secretaría Técnica (${lockData.name || 'Usuario en línea'}). Por razones de seguridad institucional y fe pública del Plenario, solo se permite un único usuario conectado a la vez en este rol. Cierre la sesión activa antes de ingresar.`
            };
          }
        } catch {
          // Ignorar y reescribir si está dañado
        }
      }

      // Registrar nuevo lock activo
      localStorage.setItem('fe_fa_secretaria_tecnica_session', JSON.stringify({
        active: true,
        tabId: currentTab,
        email: found.email,
        name: found.name,
        lastHeartbeat: Date.now()
      }));
    }

    const newSessionId = `sess-${Date.now()}`;
    const updated = { ...found, lastSessionId: newSessionId, isOnline: true };
    
    setDelegates(prev => {
      const exists = prev.some(d => d.id === found!.id);
      if (exists) {
        return prev.map(d => d.id === found!.id ? updated : d);
      }
      return [updated, ...prev];
    });

    setCurrentUser(updated);
    localStorage.setItem('fe_fa_current_user_id', updated.id);
    addAuditLog('ACREDITACION_EXITOSA', `${found.name} (${found.role}) acreditado formalmente con el correo ${found.email}.`);
    return { success: true };
  }, [delegates, getTabSessionId, addAuditLog]);

  // Heartbeat para mantener la sesión única activa de Secretaría Técnica
  useEffect(() => {
    if (!currentUser) return;
    if (currentUser.role === 'SECRETARY' || currentUser.role === 'ADMIN') {
      const currentTab = getTabSessionId();
      const interval = setInterval(() => {
        const raw = localStorage.getItem('fe_fa_secretaria_tecnica_session');
        if (raw) {
          try {
            const data = JSON.parse(raw);
            if (data.tabId === currentTab) {
              data.lastHeartbeat = Date.now();
              localStorage.setItem('fe_fa_secretaria_tecnica_session', JSON.stringify(data));
            }
          } catch {}
        }
      }, 15000);
      return () => clearInterval(interval);
    }
  }, [currentUser, getTabSessionId]);

  const logout = useCallback(() => {
    if (currentUser) {
      if (currentUser.role === 'SECRETARY' || currentUser.role === 'ADMIN') {
        const activeLock = localStorage.getItem('fe_fa_secretaria_tecnica_session');
        if (activeLock) {
          try {
            const lockData = JSON.parse(activeLock);
            if (lockData.tabId === getTabSessionId()) {
              localStorage.removeItem('fe_fa_secretaria_tecnica_session');
            }
          } catch {}
        }
      }
      addAuditLog('CIERRE_SESION', `${currentUser.name} cerró sesión en la plataforma`);
    }
    setCurrentUser(null);
    localStorage.removeItem('fe_fa_current_user_id');
    setShowLoginModal(true);
  }, [currentUser, getTabSessionId, addAuditLog]);

  // Role permissions
  const isDireccionNacional = useMemo(() => {
    return currentUser?.role === 'DIRECCION_NACIONAL' || 
           currentUser?.email.toLowerCase() === 'fe@frenteampliochile.cl';
  }, [currentUser]);

  const isSecretariaTecnica = useMemo(() => {
    return currentUser?.role === 'SECRETARY' || 
           currentUser?.role === 'ADMIN';
  }, [currentUser]);

  const isDelegate = useMemo(() => {
    return currentUser?.role === 'DELEGATE';
  }, [currentUser]);

  // Regla estricta de estatuto: Los usuarios identificados como DNE solo deben tener acceso al pleno, pero sin la parte de poder votar.
  const canVote = useMemo(() => {
    return !!currentUser && currentUser.role === 'DELEGATE';
  }, [currentUser]);

  // Actas Operations
  const createActa = useCallback((data: Partial<Acta>): Acta => {
    const code = `ACTA-2026-${String(actas.length + 1).padStart(3, '0')}`;
    const newActa: Acta = {
      id: `acta-${Date.now()}`,
      code,
      sessionTitle: data.sessionTitle || 'Nueva Sesión Plenaria FE-FA',
      sessionType: data.sessionType || 'ORDINARIA',
      date: data.date || new Date().toISOString().slice(0, 10),
      timeStart: data.timeStart || '10:00',
      timeEnd: data.timeEnd || '18:00',
      location: data.location || 'Plataforma Digital Deliberativa Oficial FE-FA',
      quorumInstallationText: data.quorumInstallationText || `Con la presencia acreditada de ${delegates.length} delegadas/os regionales se verifica el quórum estatutario para sesionar.`,
      accreditedDelegatesCount: delegates.length,
      agendaTopics: data.agendaTopics && data.agendaTopics.length > 0 ? data.agendaTopics : [
        '1. Apertura de la sesión y verificación de quórum',
        '2. Puntos en debate del Documento de Síntesis Nacional',
        '3. Votaciones parlamentarias vinculantes'
      ],
      bodyContent: data.bodyContent || 'Se da inicio a la sesión deliberativa con la participación de las bancadas de todo el país...',
      conclusions: data.conclusions && data.conclusions.length > 0 ? data.conclusions : [
        'Ratificación de los consensos alcanzados en el Plenario.'
      ],
      votedMotionIds: data.votedMotionIds || (activeMotionId ? [activeMotionId] : []),
      status: 'BORRADOR',
      digitalSignatures: [
        {
          signerName: currentUser ? currentUser.name : 'Presidencia Mesa Directiva',
          role: currentUser ? currentUser.role : 'DIRECCION_NACIONAL',
          timestamp: Date.now(),
          token: `token-${Date.now().toString(16)}`,
          status: 'PENDIENTE'
        }
      ],
      integrityHash: `hash-${Date.now().toString(16)}...sha256`,
      lastModifiedAt: Date.now(),
      lastModifiedBy: currentUser ? currentUser.name : 'Secretaría de Actas'
    };

    setActas(prev => [newActa, ...prev]);
    setActiveActaId(newActa.id);
    addAuditLog('CREACION_ACTA', `Nueva acta creada por ${currentUser?.name || 'Secretaría'}: ${code} - "${newActa.sessionTitle}"`);
    return newActa;
  }, [actas.length, delegates.length, activeMotionId, currentUser, addAuditLog]);

  const updateActa = useCallback((id: string, updates: Partial<Acta>) => {
    setActas(prev => prev.map(a => {
      if (a.id === id) {
        return {
          ...a,
          ...updates,
          lastModifiedAt: Date.now(),
          lastModifiedBy: currentUser ? currentUser.name : a.lastModifiedBy
        };
      }
      return a;
    }));
    addAuditLog('EDICION_ACTA', `Acta ${id} actualizada por ${currentUser?.name || 'Secretaría'}`);
  }, [currentUser, addAuditLog]);

  const deleteActa = useCallback((id: string) => {
    if (!isSecretariaTecnica && !isDireccionNacional) {
      return { success: false, error: 'Solo la Secretaría Técnica puede gestionar y eliminar borradores de actas.' };
    }
    const target = actas.find(a => a.id === id);
    if (!target) return { success: false, error: 'Acta no encontrada.' };
    if (target.status === 'CERTIFICADA') {
      return { success: false, error: 'No se puede eliminar un acta que ya ha sido formalmente certificada y firmada digitalmente.' };
    }

    setActas(prev => prev.filter(a => a.id !== id));
    if (activeActaId === id) {
      const remaining = actas.filter(a => a.id !== id);
      if (remaining.length > 0) setActiveActaId(remaining[0].id);
    }
    addAuditLog('ELIMINACION_ACTA', `Acta ${target.code} eliminada por ${currentUser?.name}`);
    return { success: true };
  }, [isSecretariaTecnica, isDireccionNacional, actas, activeActaId, currentUser, addAuditLog]);

  const certifyActa = useCallback((id: string) => {
    if (!isSecretariaTecnica && !isDireccionNacional) return;
    const certHash = `sha256:${Array.from('CERTIFIED' + id + Date.now()).reduce((acc, c) => ((acc << 5) - acc + c.charCodeAt(0)) | 0, 0).toString(16)}...cert`;
    
    setActas(prev => prev.map(a => {
      if (a.id === id) {
        return {
          ...a,
          status: 'CERTIFICADA',
          integrityHash: certHash,
          lastModifiedAt: Date.now(),
          lastModifiedBy: currentUser ? `${currentUser.name} (Certificación Oficial)` : a.lastModifiedBy,
          digitalSignatures: a.digitalSignatures.map(sig => ({
            ...sig,
            status: 'FIRMADO',
            timestamp: Date.now()
          }))
        };
      }
      return a;
    }));

    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.5 },
      colors: ['#4A154B', '#00796B', '#FFD700']
    });

    addAuditLog('CERTIFICACION_ACTA', `Acta ${id} certificada con firma digital por la Dirección Nacional.`);
  }, [isDireccionNacional, currentUser, addAuditLog]);

  // Voting operations: Allows changing vote while voting is open
  const castVote = useCallback((option: VoteOption, notes?: string) => {
    if (!currentUser) return;
    if (activeMotion.status !== 'VOTING') return;

    // Regla de reglamento: La Dirección Nacional puede hablar y opinar pero NO votar
    if (!canVote) {
      addAuditLog('VOTO_DENEGADO_DIRECCION', `${currentUser.name} (Dirección Nacional) no posee derecho a voto conforme a las atribuciones orgánicas del Plenario.`);
      return;
    }

    const previousVote = activeMotion.votes[currentUser.id];
    const isRectification = !!previousVote;

    const digitalSig = `fe4a-${currentUser.id.substring(0, 4)}-${Date.now().toString(16)}-voto`;

    const newVote = {
      delegateId: currentUser.id,
      delegateName: currentUser.name,
      region: currentUser.region,
      vote: option,
      timestamp: Date.now(),
      digitalSignatureHash: digitalSig,
      notes: notes || undefined
    };

    setMotionsHistory(prev => prev.map(m => {
      if (m.id === activeMotion.id) {
        return {
          ...m,
          votes: {
            ...m.votes,
            [currentUser.id]: newVote
          }
        };
      }
      return m;
    }));

    if (isRectification) {
      addAuditLog('RECTIFICACION_VOTO', `${currentUser.name} (${currentUser.region}) rectificó su voto a [${option}] (anterior: ${previousVote.vote}) en moción ${activeMotion.code}.`);
    } else {
      addAuditLog('EMISION_VOTO', `${currentUser.name} (${currentUser.region}) emitió voto [${option}] en moción ${activeMotion.code}. Hash: ${digitalSig}`);
    }
  }, [currentUser, activeMotion, canVote, addAuditLog]);

  const openVotingForMotion = useCallback((motionId: string) => {
    if (!isDireccionNacional && !isSecretariaTecnica) {
      addAuditLog('ACCION_DENEGADA', `${currentUser?.name || 'Usuario'} sin permisos intentó abrir votación.`);
      return;
    }
    setMotionsHistory(prev => prev.map(m => {
      if (m.id === motionId) {
        return {
          ...m,
          status: 'VOTING',
          startedAt: Date.now()
        };
      }
      return m;
    }));
    setActiveMotionId(motionId);
    addAuditLog('APERTURA_VOTACION', `Votación formal iniciada por ${currentUser?.name} para la moción ${motionId}`);
  }, [isDireccionNacional, isSecretariaTecnica, currentUser, addAuditLog]);

  const closeVotingForMotion = useCallback((motionId: string) => {
    if (!isDireccionNacional && !isSecretariaTecnica) {
      addAuditLog('ACCION_DENEGADA', `${currentUser?.name || 'Usuario'} sin permisos intentó cerrar votación.`);
      return;
    }
    setMotionsHistory(prev => prev.map(m => {
      if (m.id === motionId) {
        // Solo las delegadas y delegados regionales componen el padrón de votación vinculante
        const eligible = delegates.filter(d => d.role === 'DELEGATE').length;
        const votesArray = Object.values(m.votes);
        const castCount = votesArray.length;
        const aFavor = votesArray.filter(v => v.vote === 'A_FAVOR').length;
        const enContra = votesArray.filter(v => v.vote === 'EN_CONTRA').length;
        const abstencion = votesArray.filter(v => v.vote === 'ABSTENCION').length;
        
        const validVotes = aFavor + enContra;
        const percentageFavor = castCount > 0 ? (aFavor / castCount) * 100 : 0;
        
        // Quorum of session participation (minimum 50% participation)
        const quorumMet = castCount >= Math.ceil(eligible * 0.5);
        
        // Majority condition
        let isApproved = false;
        if (quorumMet && validVotes > 0) {
          if (m.quorumType === 'TWO_THIRDS') {
            isApproved = (aFavor / validVotes) >= (2 / 3);
          } else {
            isApproved = aFavor > enContra;
          }
        }

        if (isApproved) {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#6A1B9A', '#D32F2F', '#FFFFFF', '#FFD700']
          });
        }

        const summary = {
          totalEligible: eligible,
          totalCast: castCount,
          aFavor,
          enContra,
          abstencion,
          percentageFavor: Math.round(percentageFavor * 10) / 10,
          quorumMet,
          isApproved
        };

        return {
          ...m,
          status: isApproved ? 'APPROVED' : 'REJECTED',
          closedAt: Date.now(),
          resultSummary: summary
        };
      }
      return m;
    }));

    addAuditLog('CIERRE_VOTACION', `Escrutinio público formal finalizado por ${currentUser?.name} para ${motionId}.`);
  }, [isDireccionNacional, isSecretariaTecnica, currentUser, delegates, addAuditLog]);

  const createNewMotion = useCallback((
    title: string, 
    description: string, 
    quorumType: 'SIMPLE_MAJORITY' | 'TWO_THIRDS',
    immediateLaunch: boolean = true,
    durationSeconds: number = 300
  ): Motion | undefined => {
    if (!isDireccionNacional && !isSecretariaTecnica) {
      addAuditLog('ACCION_DENEGADA', `${currentUser?.name || 'Usuario'} sin permisos intentó crear una nueva moción.`);
      return undefined;
    }
    const code = `MOC-2026-${String(motionsHistory.length + 1).padStart(3, '0')}`;
    const newMotion: Motion = {
      id: `moc-${Date.now()}`,
      code,
      title,
      description,
      proposedBy: currentUser ? `${currentUser.name} (${currentUser.role === 'SECRETARY' ? 'Secretaría Técnica' : currentUser.role})` : 'Mesa Directiva',
      status: immediateLaunch ? 'VOTING' : 'OPEN',
      quorumType,
      createdAt: Date.now(),
      startedAt: immediateLaunch ? Date.now() : undefined,
      durationSeconds: durationSeconds || 300,
      votes: {}
    };

    setMotionsHistory(prev => [newMotion, ...prev]);
    setActiveMotionId(newMotion.id);
    addAuditLog('NUEVA_MOCION', `Nueva moción presentada por ${currentUser?.name}: ${code} - "${title}"${immediateLaunch ? ' [VOTACIÓN LANZADA INMEDIATAMENTE]' : ''}`);
    return newMotion;
  }, [isDireccionNacional, isSecretariaTecnica, currentUser, motionsHistory.length, addAuditLog]);

  // Synthesis modifications
  const updateChapterContent = useCallback((chapterId: string, newContent: string) => {
    setSynthesisChapters(prev => prev.map(ch => {
      if (ch.id === chapterId) {
        return {
          ...ch,
          content: newContent,
          lastModifiedBy: currentUser ? `${currentUser.name} (${currentUser.role})` : 'Secretaría de Actas',
          lastModifiedAt: Date.now()
        };
      }
      return ch;
    }));
    addAuditLog('EDICION_SINTESIS', `Secretaría actualizó texto oficial del Capítulo ${chapterId}`);
  }, [currentUser, addAuditLog]);

  const addChangeProposal = useCallback((chapterId: string, proposedText: string, justification: string, type: 'CONSENSO' | 'DISENSO') => {
    if (!currentUser) return;
    const newProposal: ChangeProposal = {
      id: `prop-${Date.now()}`,
      chapterId,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRegion: currentUser.region,
      type,
      originalText: '',
      proposedText,
      justification,
      status: type === 'CONSENSO' ? 'ACCEPTED' : 'IN_DEBATE',
      votesFavor: 1,
      votesContra: 0,
      createdAt: Date.now()
    };

    setSynthesisChapters(prev => prev.map(ch => {
      if (ch.id === chapterId) {
        if (type === 'CONSENSO') {
          return {
            ...ch,
            consensusItems: [...ch.consensusItems, proposedText],
            lastModifiedBy: currentUser.name,
            lastModifiedAt: Date.now()
          };
        } else {
          return {
            ...ch,
            dissensusItems: [...ch.dissensusItems, newProposal],
            lastModifiedBy: currentUser.name,
            lastModifiedAt: Date.now()
          };
        }
      }
      return ch;
    }));

    addAuditLog('PROPUESTA_INDICACION', `${currentUser.name} propuso nueva indicación/disenso en Capítulo: "${proposedText.substring(0, 40)}..."`);
  }, [currentUser, addAuditLog]);

  const voteChangeProposal = useCallback((chapterId: string, proposalId: string, vote: 'FAVOR' | 'CONTRA') => {
    setSynthesisChapters(prev => prev.map(ch => {
      if (ch.id === chapterId) {
        return {
          ...ch,
          dissensusItems: ch.dissensusItems.map(p => {
            if (p.id === proposalId) {
              return {
                ...p,
                votesFavor: vote === 'FAVOR' ? p.votesFavor + 1 : p.votesFavor,
                votesContra: vote === 'CONTRA' ? p.votesContra + 1 : p.votesContra
              };
            }
            return p;
          })
        };
      }
      return ch;
    }));
  }, []);

  const elevateProposalToMotion = useCallback((chapterId: string, proposalId: string) => {
    const chapter = synthesisChapters.find(ch => ch.id === chapterId);
    const proposal = chapter?.dissensusItems.find(p => p.id === proposalId);
    if (!proposal) return;

    createNewMotion(
      `Indicación sobre ${chapter?.title.split(':')[0] || 'Síntesis'}`,
      `Texto propuesto por ${proposal.authorName} (${proposal.authorRegion}): "${proposal.proposedText}". Fundamentación: ${proposal.justification}`,
      'SIMPLE_MAJORITY'
    );
    setActiveTab('plenario');
    addAuditLog('ELEVACION_DISENSO', `Disenso elevado a votación parlamentaria formal en el Plenario`);
  }, [synthesisChapters, createNewMotion, addAuditLog]);

  // Order motions
  const sendOrderMotion = useCallback((category: OrderMotionCategory, message: string) => {
    if (!currentUser) return;
    const newOrder: OrderMotion = {
      id: `om-${Date.now()}`,
      delegateId: currentUser.id,
      delegateName: `${currentUser.name} (${currentUser.region})`,
      region: currentUser.region,
      category,
      message,
      timestamp: Date.now(),
      status: 'PENDIENTE'
    };
    setOrderMotions(prev => [newOrder, ...prev]);
    addAuditLog('MOCION_ORDEN', `${currentUser.name} envió [${category}]: ${message.substring(0, 50)}...`);
  }, [currentUser, addAuditLog]);

  const resolveOrderMotion = useCallback((id: string, newStatus: 'ATENDIDA' | 'DESESTIMADA') => {
    setOrderMotions(prev => prev.map(om => {
      if (om.id === id) {
        return {
          ...om,
          status: newStatus,
          resolvedBy: currentUser?.name || 'Mesa Directiva'
        };
      }
      return om;
    }));
    addAuditLog('RESOLUCION_MOCION_ORDEN', `Mesa Directiva declaró ${newStatus} la moción de orden ${id}`);
  }, [currentUser, addAuditLog]);

  // CSV Ingestion for Padron
  const importDelegatesCSV = useCallback((csvText: string) => {
    try {
      const lines = csvText.split('\n').map(l => l.trim()).filter(Boolean);
      if (lines.length < 2) return { success: false, count: 0, error: 'El archivo está vacío o no contiene filas' };

      const parsed: Delegate[] = [];
      // Skip header
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',').map(p => p.trim().replace(/^"|"$/g, ''));
        if (parts.length >= 4) {
          const [name, email, region, roleStr, genderStr, org] = parts;
          parsed.push({
            id: `del-csv-${Date.now()}-${i}`,
            name: name || `Delegado/a ${i}`,
            email: email || `delegado${i}@fe-fa.cl`,
            region: (region as ChileanRegion) || 'Metropolitana',
            role: (roleStr as UserRole) || 'DELEGATE',
            gender: (genderStr as any) || 'Femenino',
            organization: org || 'Federación Estudiantil Regional',
            isOnline: true,
            hasSpokenInCurrentMotion: false,
            ipAddress: `190.161.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`
          });
        }
      }

      if (parsed.length > 0) {
        setDelegates(prev => [...prev, ...parsed]);
        addAuditLog('CARGA_MASIVA_CSV', `Carga exitosa de ${parsed.length} delegadas/os al padrón oficial`);
        return { success: true, count: parsed.length };
      }
      return { success: false, count: 0, error: 'Formato CSV no reconocido. Columnas requeridas: Nombre, Correo, Región, Rol' };
    } catch (e: any) {
      return { success: false, count: 0, error: e.message || 'Error procesando archivo CSV' };
    }
  }, [addAuditLog]);

  const exportPadronCSV = useCallback(() => {
    const headers = ['ID,Nombre,Correo,Región,Género,Rol,Organización,Estado'];
    const rows = delegates.map(d => 
      `"${d.id}","${d.name}","${d.email}","${d.region}","${d.gender}","${d.role}","${d.organization}","${d.isOnline ? 'Online' : 'Offline'}"`
    );
    const content = [headers, ...rows].join('\n');
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Padron_Oficial_FE-FA_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addAuditLog('EXPORTACION_PADRON_CSV', `Exportación de padrón con ${delegates.length} registros`);
  }, [delegates, addAuditLog]);

  const exportActaCSV = useCallback(() => {
    const headers = ['Moción,Delegado,Región,Voto,Timestamp,FirmaDigitalHash'];
    const rows: string[] = [];
    motionsHistory.forEach(m => {
      Object.values(m.votes).forEach(v => {
        rows.push(`"${m.code} - ${m.title.replace(/"/g, '""')}","${v.delegateName}","${v.region}","${v.vote}","${new Date(v.timestamp).toISOString()}","${v.digitalSignatureHash}"`);
      });
    });
    const content = [headers, ...rows].join('\n');
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Acta_Votaciones_FE-FA_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addAuditLog('EXPORTACION_ACTA_CSV', `Exportación de acta de votaciones nominales`);
  }, [motionsHistory, addAuditLog]);

  const resetAllData = useCallback(() => {
    localStorage.clear();
    setDelegates(INITIAL_DELEGATES);
    setCurrentUser(INITIAL_DELEGATES[0]);
    setMotionsHistory(INITIAL_MOTIONS);
    setSynthesisChapters(INITIAL_SYNTHESIS_CHAPTERS);
    setOrderMotions(INITIAL_ORDER_MOTIONS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setActiveMotionId('moc-002');
    addAuditLog('REINICIO_SISTEMA', `Restablecimiento de fábrica del entorno deliberativo`);
  }, [addAuditLog]);

  return (
    <PlenarioContext.Provider value={{
      currentUser,
      setCurrentUser,
      delegates,
      activeTab,
      setActiveTab,
      activeMotion,
      activeMotionId,
      setActiveMotionId,
      motionsHistory,
      speakerQueue,
      activeSpeaker,
      timerSeconds,
      timerTotal,
      isTimerRunning,
      lowBandwidthMode,
      setLowBandwidthMode,
      forceMuted,
      setForceMuted,
      synthesisChapters,
      orderMotions,
      auditLogs,
      actas,
      activeActaId,
      setActiveActaId,
      createActa,
      updateActa,
      deleteActa,
      certifyActa,
      isDireccionNacional,
      isSecretariaTecnica,
      isDelegate,
      canVote,
      showLoginModal,
      setShowLoginModal,
      loginWithEmail,
      logout,
      castVote,
      openVotingForMotion,
      closeVotingForMotion,
      createNewMotion,
      deleteDelegate,
      updateDelegate,
      addDelegate,
      requestWord,
      withdrawWord,
      takeFloorAsPresidency,
      giveWordToSpeaker,
      finishSpeaking,
      startTimer,
      pauseTimer,
      resetTimer,
      addThirtySeconds,
      updateChapterContent,
      addChangeProposal,
      voteChangeProposal,
      elevateProposalToMotion,
      sendOrderMotion,
      resolveOrderMotion,
      importDelegatesCSV,
      exportPadronCSV,
      exportActaCSV,
      addAuditLog,
      resetAllData
    }}>
      {children}
    </PlenarioContext.Provider>
  );
};

export const usePlenario = () => {
  const context = useContext(PlenarioContext);
  if (!context) throw new Error('usePlenario must be used within a PlenarioProvider');
  return context;
};
